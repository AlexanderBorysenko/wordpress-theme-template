<?php
get_header();
$taxonomies = array('fitler_home_style', 'fitler_garage_location');

$args = array(
    'post_type' => 'home-design',
    'posts_per_page' => get_query_var('posts_per_page'),
    'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
);

$current_filters = array();
foreach ($taxonomies as $taxonomy) {
    $current_filters[$taxonomy] = isset ($_GET[$taxonomy]) ? (array) $_GET[$taxonomy] : array();
}

foreach ($current_filters as $taxonomy => $terms) {
    $terms = array_filter($terms);
    if (!empty ($terms)) {
        $args['tax_query'][] = array(
            'taxonomy' => $taxonomy,
            'field' => 'slug',
            'terms' => $terms,
        );
    }
}

global $query;
$query = new WP_Query($args);

?>
<?=
    component(
        'breadcrumbs',
    );
?>
<?=
    component(
        'simple-hero',
        [
            'title' => carbon_get_theme_option('crb_home_design_archive_hero_title'),
            'content' => apply_filters('the_content', carbon_get_theme_option('crb_home_design_archive_hero_content')),
            'class' => 'pb-2-5',
        ]
    );
?>
<div class="container">
    <div class="archive-main-wrapper grid gap-1 mb-2-5">
        <?= component('archive-filters', [
            'taxonomies' => $taxonomies,
            'class' => 'grid-col-3 grid-tw-col-12',
        ]) ?>
        <?php
        if ($query->have_posts()) {
            ?>
            <div class="grid-col-9 grid-tw-col-12 grid gap-1">
                <?php
                while ($query->have_posts()) {
                    $query->the_post();
                    component('home-design-card', [
                        'title' => get_the_title(),
                        'image' => get_image(get_post_thumbnail_id()),
                        'bedrooms' => carbon_get_the_post_meta('crb_bedrooms'),
                        'bathrooms' => carbon_get_the_post_meta('crb_bathrooms'),
                        'sq_ft' => carbon_get_the_post_meta('crb_sq_ft'),
                        'plan_type' => carbon_get_the_post_meta('crb_plan_type'),
                        'href' => get_permalink(),
                        'class' => '_archive-type grid-col-4 grid-sdw-col-6 grid-tw-col-12',
                    ]);
                }
                wp_reset_postdata();
                ?>
                <div class="grid-col-12">
                    <?= component('pagination') ?>
                </div>
            </div>
            <?php
        } else {
            ?>
            <div class="grid-col-9">
                <?=
                    component('section-title', [
                        'text' => 'No quick possession homes found.',
                    ]);
                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>
<?=
    component('contact-us-section');
?>
<?php
get_footer();