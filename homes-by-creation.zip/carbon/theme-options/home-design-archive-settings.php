<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make('theme_options', 'Archive Page Settings')
    ->set_page_parent('edit.php?post_type=home-design')
    ->add_fields([
        Field::make('text', 'crb_home_design_archive_hero_title', 'Hero Title'),
        Field::make('rich_text', 'crb_home_design_archive_hero_content', 'Hero Content'),
    ]);

