<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

$basic_options_container = Container::make('theme_options', 'Gallery Portfolio')
    ->set_icon('dashicons-format-gallery')
    ->add_fields([
        Field::make('association', 'crb_gallery_portfolio_page', 'Gallery Portfolio Page')
            ->set_types([
                [
                    'type' => 'post',
                    'post_type' => 'page',
                ],
            ])
            ->set_max(1),

        Field::make('media_gallery', 'crb_gallery_portfolio', 'Gallery Portfolio')
    ]);

