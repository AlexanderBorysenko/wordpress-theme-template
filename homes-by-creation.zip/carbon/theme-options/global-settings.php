<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

$basic_options_container = Container::make('theme_options', __('Global Theme Settings'))
    ->add_fields([
        Field::make('header_scripts', 'crb_header_script', __('Header Script')),
        Field::make('footer_scripts', 'crb_footer_script', __('Footer Script')),
    ]);

Container::make('theme_options', __('Contacts'))
    ->set_page_parent($basic_options_container)
    ->add_tab('General', [
        Field::make('text', 'crb_email', __('Email'))->set_default_value('sales@homesbycreation.ca'),
        Field::make('text', 'crb_phone', __('Phone'))->set_default_value('(587) 894-7677'),
    ])
    ->add_tab('Address(s)', [
        Field::make('text', 'crb_head_office_address_first_line', __('Head Office Address First Line'))
            ->set_default_value('273104 RANGE ROAD 293'),
        Field::make('text', 'crb_head_office_address_second_line', __('Head Office Address Second Line'))
            ->set_default_value('AIRDRIE, AB T4A 1L1'),

        Field::make('complex', 'crb_office_locations', __('Office Locations'))
            ->add_fields('office', [
                Field::make('text', 'title', __('Title')),
                Field::make('text', 'address', __('Address')),
            ])->set_layout('tabbed-horizontal')->set_header_template('<%- title %>'),
    ])
    ->add_tab('Contact Form', [
        Field::make('text', 'crb_contact_page_link', __('Contact Us Page Link'))->set_default_value('/contact-us'),
        Field::make('text', 'crb_email_to', __('Send Emails To'))->set_default_value('sales@homesbycreation.ca'),
        Field::make('text', 'crb_thank_you_page_link', __('Thank You Page Link'))->set_default_value('/thank-you'),
    ])
    ->add_tab('Social Media', [
        Field::make('text', 'crb_facebook_link', __('Facebook Link'))->set_default_value('https://www.facebook.com/homesbycreation/'),
        Field::make('text', 'crb_instagram_link', __('Instagram Link'))->set_width(50)->set_default_value('https://www.instagram.com/homesbycreation/'),
        Field::make('text', 'crb_instagram_name', __('Instagram Name'))->set_width(50)->set_default_value('@homesbycreation'),
        Field::make('text', 'crb_linkedin_link', __('LinkedIn Link'))->set_default_value('https://www.linkedin.com/company/homes-by-creation?originalSubdomain=ca'),
        Field::make('text', 'crb_twitter_link', __('Twitter Link'))->set_default_value('https://twitter.com/homesbycreation'),
        Field::make('text', 'crb_youtube_link', __('YouTube Link')),
    ]);