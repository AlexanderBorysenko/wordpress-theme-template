<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make('post_meta', 'Team Member Data')
    ->where('post_type', '=', 'team-member')
    ->add_fields([
        Field::make('text', 'crb_role', 'Role'),
        Field::make('text', 'crb_phone', 'Phone'),
        Field::make('text', 'crb_email', 'Email'),
    ]);
