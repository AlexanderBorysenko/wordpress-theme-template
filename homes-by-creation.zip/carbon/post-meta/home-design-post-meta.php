<?php
// home-design carbon postmeta (in sidebar) : [bedrooms_count, bathrooms_count, sq_ft]
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make('post_meta', 'Home Design Data')
    ->where('post_type', '=', 'home-design')
    ->add_fields([
        Field::make('text', 'crb_plan_type', 'Plan Type'),
        Field::make('text', 'crb_bedrooms', 'Bedrooms'),
        Field::make('text', 'crb_bathrooms', 'Bathrooms'),
        Field::make('text', 'crb_sq_ft', 'Square Feet'),
    ])->set_context('side');