<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

// quick-possession post type meta fields [crb_bedrooms, crb_bathrooms, crb_sq_ft] set context to sidebar

Container::make('post_meta', 'Quick Possession Data')
    ->where('post_type', '=', 'quick-possession')
    ->add_fields([
        Field::make('checkbox', 'crb_is_available', 'Is Available'),
        Field::make('text', 'crb_community_name', 'Community Name'),
        Field::make('text', 'crb_bedrooms', 'Bedrooms'),
        Field::make('text', 'crb_bathrooms', 'Bathrooms'),
        Field::make('text', 'crb_sq_ft', 'Square Feet'),
    ])->set_context('side');