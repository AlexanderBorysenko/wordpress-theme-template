<?php
use Carbon_Fields\Container;
use Carbon_Fields\Field;

// community post type meta fields [crb_location] set context to sidebar
Container::make('post_meta', 'Community Data')
    ->where('post_type', '=', 'community')
    ->add_fields([
        Field::make('text', 'crb_location', 'Location'),
    ])->set_context('side');