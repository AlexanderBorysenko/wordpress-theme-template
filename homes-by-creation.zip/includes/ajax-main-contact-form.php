<?php
// ajax action for main contact form
add_action('wp_ajax_main_contact_form_submit', 'main_contact_form_submit');
add_action('wp_ajax_nopriv_main_contact_form_submit', 'main_contact_form_submit');

function main_contact_form_submit()
{
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    if (empty($name) || empty($subject) || empty($phone) || empty($email)) {
        return wp_send_json_error('Please fill in all required fields');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return wp_send_json_error('Please enter a valid email address');
    }

    $to = carbon_get_theme_option('crb_email_to');
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
    $subject = 'New lead from ' . $name . ' - ' . $subject . '';
    $body = '<p><strong>Name:</strong> ' . $name . '</p>';
    $body .= '<p><strong>Subject:</strong> ' . $subject . '</p>';
    $body .= '<p><strong>Phone:</strong> ' . $phone . '</p>';
    $body .= '<p><strong>Email:</strong> ' . $email . '</p>';
    $body .= '<p><strong>Message:</strong> ' . $message . '</p>';

    try {
        wp_mail($to, $subject, $body, $headers);
    } catch (Exception $e) {
        return wp_send_json_error('An error occurred while sending the message. Please try again later.');
    }

    wp_send_json_success([
        'redirect' => carbon_get_theme_option('crb_thank_you_page_link'),
    ]);

    exit;
}