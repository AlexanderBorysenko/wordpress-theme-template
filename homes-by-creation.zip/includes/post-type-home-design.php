<?php
// init Home Design post type
add_action('init', function () {
    register_post_type('home-design', [
        'labels' => [
            'name' => __('Home Designs'),
            'singular_name' => __('Home Design'),
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-admin-home',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
    ]);
});

add_action('pre_get_posts', function ($query) {
    if (is_post_type_archive('quick-possession') && $query->is_main_query()) {
        $query->set('posts_per_page', 12);
    }
});