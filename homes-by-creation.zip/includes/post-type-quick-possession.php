<?php
add_action('init', function () {
    register_post_type('quick-possession', [
        'labels' => [
            'name' => __('Quick Possessions'),
            'singular_name' => __('Quick Possession'),
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-admin-home',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_rest' => true,
        // setup template for quick possession [carbon-fields/building-overview-section {margin_bottom=mb-3}, carbon-fields/building-sales-section {margin_bottom=mb-6}, carbon-fields/contact-us-section]
        'template' => [
            [
                'carbon-fields/building-overview-section',
                [
                    'margin_bottom' => 'mb-3',
                ],
            ],
            [
                'carbon-fields/building-sales-section',
                [
                    'margin_bottom' => 'mb-6',
                ],
            ],
            [
                'carbon-fields/contact-us-section',
            ],
        ],
    ]);
});

add_action('pre_get_posts', function ($query) {
    if (is_post_type_archive('quick-possession') && $query->is_main_query()) {
        $query->set('posts_per_page', 12);
    }
});