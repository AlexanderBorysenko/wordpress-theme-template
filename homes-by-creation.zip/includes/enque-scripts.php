<?php
function clear_styles_and_scripts()
{
    if (is_user_logged_in())
        return;

    global $wp_scripts;
    global $wp_styles;

    foreach ($wp_scripts->queue as $handle) {
        wp_dequeue_script($handle);
        wp_deregister_script($handle);
    }

    foreach ($wp_styles->queue as $handle) {
        wp_dequeue_style($handle);
        wp_deregister_style($handle);
    }
}
add_action('wp_enqueue_scripts', 'clear_styles_and_scripts', 100);

function homes_by_creation_scripts()
{
    wp_enqueue_style('homes_by_creation-main-style', get_template_directory_uri() . '/source/build/' . resolveBuildFileName('app-*.css'), array());

    wp_enqueue_script('homes_by_creation-main-js', get_template_directory_uri() . '/source/build/' . resolveBuildFileName('app-*.js'));
}
add_action('wp_enqueue_scripts', 'homes_by_creation_scripts', 101);

function homes_by_creation_admin_scripts()
{
    wp_enqueue_style('homes_by_creation-admin-style', get_template_directory_uri() . '/source/build/' . resolveBuildFileName('wp-admin-*.css'), array());
    // wp_enqueue_script('homes_by_creation-wp-admin-js', get_template_directory_uri() . '/build/wp-admin-' . _S_VERSION . '.min.js', array(), _S_VERSION, true);
}
add_action('admin_enqueue_scripts', 'homes_by_creation_admin_scripts');