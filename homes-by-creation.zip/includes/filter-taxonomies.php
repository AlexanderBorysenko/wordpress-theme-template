<?php
function register_custom_taxonomy($name, $singular_name, $slug, $post_type = [])
{
    $labels = array(
        'name' => $name,
        'singular_name' => $singular_name,
    );

    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'show_in_rest' => true,
        'meta_box_cb' => 'post_categories_meta_box',

        'public' => false,
    );

    register_taxonomy($slug, $post_type, $args);
}

function register_taxonomies()
{
    register_custom_taxonomy('Home Styles', 'Home Style', 'fitler_home_style', [
        'quick-possession',
        'home-design'
    ]);
    register_custom_taxonomy('Communities', 'Community', 'fitler_community', [
        'quick-possession',
    ]);
    register_custom_taxonomy('Garage Locations', 'Garage Location', 'fitler_garage_location', [
        'quick-possession',
        'home-design'
    ]);
    register_custom_taxonomy('Availabilities', 'Availability', 'fitler_availability', [
        'quick-possession',
    ]);
}

add_action('init', 'register_taxonomies', 0);