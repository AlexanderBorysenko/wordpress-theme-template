<?php
add_action('init', function () {
    register_post_type('team-member', [
        'labels' => [
            'name' => 'Team Members',
            'singular_name' => 'Team Member',
            'add_new_item' => 'Add New Team Member',
            'edit_item' => 'Edit Team Member',
            'search_items' => 'Search Team Members',
            'not_found' => 'No Team Members found.',
            'not_found_in_trash' => 'No Team Members found in Trash.',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-groups',
        'supports' => ['title', 'thumbnail'],
        'has_archive' => false,
        'rewrite' => false,
    ]);
});