<?php
// community post type
add_action('init', function () {
    register_post_type('community', [
        'labels' => [
            'name' => __('Communities'),
            'singular_name' => __('Community'),
        ],
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-location-alt',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_rest' => true,
    ]);
});