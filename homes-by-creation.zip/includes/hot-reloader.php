<?php
function get_version()
{
    $fileName = resolveBuildFileName('app-*.css');
    if (!$fileName) {
        return false;
    }

    $version = filemtime(get_template_directory() . '/source/build/' . resolveBuildFileName('app-*.css'));
    return $version;
}
function ajax_get_version()
{
    wp_send_json(get_version());
    wp_die();
}

add_action('wp_ajax_get_current_version', 'ajax_get_version');
add_action('wp_ajax_nopriv_get_current_version', 'ajax_get_version');

// add script to wp_head which does following: - from php executes get_version() into `var currentVersion`, in a lopp of each 500ms it sends request to server to get current version, if it's different from `currentVersion` it saves current scroll position in the shouldScroll sessionStorage and reloads the page
add_action('wp_head', function () {
    ?>
    <script>
        var currentVersion = <?= get_version() ?>;
        setInterval(function ()
        {
            fetch('/wp-admin/admin-ajax.php?action=get_current_version')
                .then(response => response.json())
                .then(version =>
                {
                    if (!version) return;

                    if (version !== currentVersion)
                    {
                        sessionStorage.setItem('shouldScroll', window.scrollY);
                        location.reload();
                    }
                });
        }, 500);
    </script>
    <?php
}, 1);