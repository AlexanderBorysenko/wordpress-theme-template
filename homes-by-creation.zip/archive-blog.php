<?php
get_header();
?>

<?=
    component(
        'breadcrumbs',
    );
?>
<?=
    component(
        'simple-hero',
        [
            'title' => carbon_get_theme_option('crb_blog_archive_hero_title'),
            'content' => apply_filters('the_content', carbon_get_theme_option('crb_blog_archive_hero_content')),
            'class' => 'pb-2-5',
        ]
    );
?>

<div class="container">
    <div class="archive-main-wrapper mb-2-5">
        <?php
        global $posts;
        component(
            'blog-posts-list',
            [
                'items' => $posts,
                'class' => 'grid-col-'
            ]
        );
        ?>
        <?= component('pagination') ?>
    </div>
</div>

<?=
    component('contact-us-section');
?>

<?php
get_footer();