import './app.scss';

import initHeaderComponent from './components/header-component';
import initMegaMenu from './components/base-megamenu';
import { initHeaderNavigation } from './components/header-navigation';
import initMobileMegamenu from './components/mobile-megamenu';
import initLogosCarousel from './components/logos-carousel';
import initHomeDesignsSlider from './components/home-designs-slider';
import initCommunitiesDemonstrationSection from './components/communities-demonstration-section';
import { initImageViewModal } from './components/image-view-modal';
import { initGallery } from './components/gallery';
import { initContactInformationSection } from './components/contact-information-section';
import { initContactForms } from './components/contact-form';
import { initFilterItems } from './components/filter-item';
import initQBuildingOverviwGallerySlider from './components/building-overview-gallery-slider';
import initSimpleGallerySlider from './components/simple-gallery-slider';

window.addEventListener('load', () => {
    initHeaderComponent();
    initMegaMenu();
    initHeaderNavigation();
    initMobileMegamenu();
    initLogosCarousel();
    initHomeDesignsSlider();
    initCommunitiesDemonstrationSection();
    initImageViewModal();
    initGallery();
    initContactInformationSection();
    initSimpleGallerySlider();
    initContactForms();
    initFilterItems();
    initQBuildingOverviwGallerySlider();
});