<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('building-overview-section', 'Building Overview')
    ->add_tab('Content', [
        Field::make('image', 'logo', 'Logo'),
        Field::make('text', 'top_price', 'Top Price'),
        Field::make('text', 'bottom_price', 'Bottom Price'),
        Field::make('text', 'title', 'Title'),
        Field::make('text', 'subtitle', 'Subtitle'),
        Field::make('rich_text', 'content', 'Content'),
        Field::make('text', 'floor_plan', 'Floor Plan Link'),
    ])
    ->add_tab('Gallery', [
        Field::make('media_gallery', 'images', 'Images'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_icon('admin-home')
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('building-overview-section', [
            'logo' => get_image($logo),
            'title' => $title,
            'subtitle' => $subtitle,
            'top_price' => $top_price,
            'bottom_price' => $bottom_price,
            'content' => apply_filters('the_content', $content),
            'images' => array_map(function ($image) {
                return get_image($image);
            }, $images),
            'class' => $margin_bottom,
            'floor_plan' => $floor_plan,
        ]);
    });