<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('sub-hero-banner', 'Sub Hero Banner')
    ->add_tab('Content', [
        Field::make('text', 'title', 'Title')->set_default_value('Sub Hero Banner'),
        Field::make('rich_text', 'content', 'Content')->set_default_value('This is a sub hero banner.'),
        Field::make('image', 'image', 'Image'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('align-none')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('sub-hero-banner', [
            'title' => $title,
            'content' => apply_filters('the_content', $content),
            'image' => get_image($image),
            'class' => $margin_bottom,
        ]);
    });