import { saveScroll } from "../scripts/scrollSaver";

// seek for filter-item, on input change get closest form and submit it
export const initFilterItems = () => {
    const filterItems = document.querySelectorAll('.filter-item');
    filterItems.forEach((filterItem) => {
        filterItem.addEventListener('change', () => {
            const form = filterItem.closest('form');
            if (form) {
                saveScroll();
                form.submit();
            }
        });
    });
};