<section class="gallery-preview-section container <?= $class ?>">
    <div class="flex-row justify-between gap-2 align-end mb-3-5">
        <hgroup>
            <?php
            if ($pre_title):
                component(
                    'decorated-pre-section-title',
                    [
                        'class' => 'mb-1-5',
                        'text' => $pre_title
                    ]
                );
            endif;

            component('section-title', [
                'class' => 'lh-100',
                'text' => $title
            ]);
            ?>
        </hgroup>
        <?php
        $gallery_page = carbon_get_theme_option('crb_gallery_portfolio_page');
        if (count($gallery_page)):
            component('primary-button', [
                'class' => '_light-bordered home-designs-preview-slider-section__button',
                'href' => get_permalink(carbon_get_theme_option('crb_gallery_portfolio_page')[0]['id']),
                'text' => 'View all Gallery'
            ]);
        endif;
        ?>
    </div>
    <?=
        component('gallery', [
            'limit' => 12
        ]);
    ?>
</section>
