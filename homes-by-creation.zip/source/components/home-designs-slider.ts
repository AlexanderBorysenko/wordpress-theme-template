import Swiper from 'swiper';
import { Autoplay } from 'swiper/modules';


const initHomeDesignsSlider = () => {
    // .logos-carousel infinite auto slider
    const carousels = document.querySelectorAll<HTMLElement>('.home-designs-slider');

    carousels.forEach(carousel => {
        new Swiper(carousel, {
            slidesPerView: 1,
            spaceBetween: 16,
            modules: [Autoplay],
            speed: 1000,
            autoplay: {
                delay: 2000,
                disableOnInteraction: true,
                pauseOnMouseEnter: true,
            },
            breakpoints: {
                768: {
                    slidesPerView: 'auto',

                },
            }
        });
    });

}

export default initHomeDesignsSlider