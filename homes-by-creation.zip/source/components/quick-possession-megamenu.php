<?php
ob_start();
?>
<div class="flex-row justify-between align-end mb-1">
    <h2 class="ls-1 color-grey fw-600 fs-1 uppercase">Move in ready</h2>
    <a href="#" class="quick-possession-megamenu__view-all">View all</a>
</div>
<div class="grid gap-1">
    <?php
    $quick_possessions = new WP_Query([
        'posts_per_page' => 4,
        'post_type' => 'quick-possession',
        'post_status' => 'publish',
    ]);
    while ($quick_possessions->have_posts()):
        $quick_possessions->the_post();
        component(
            'quick-possession-card',
            [
                'title' => get_the_title(),
                'is_available' => carbon_get_the_post_meta('crb_is_available'),
                'image' => get_image(
                    get_post_thumbnail_id(),
                    'medium'
                ),
                'href' => get_the_permalink(),
                'bedrooms' => carbon_get_the_post_meta('crb_bedrooms'),
                'bathrooms' => carbon_get_the_post_meta('crb_bathrooms'),
                'sq_ft' => carbon_get_the_post_meta('crb_sq_ft'),
                'class' => '_navigation-type grid-col-3 grid-tw-col-6 grid-mw-col-12'
            ]
        );
        wp_reset_postdata();
    endwhile;
    ?>
</div>
<?php
$slot = ob_get_clean();

component('base-megamenu', [
    'class' => 'quick-possession-megamenu',
    'id' => 'quick-possession-megamenu',
    'slot' => $slot
]);
?>
