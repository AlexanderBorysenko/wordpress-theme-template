<article class="home-design-card <?= $class ?>">
    <a href="<?= $href ?>" class="home-design-card__image-wrapper">
        <img src="<?= $image['src'] ?>" alt=<?= $title ?> width="<?= $image['width'] ?>" height="<?= $image['height'] ?>"
            srcset="<?= $image['srcset'] ?>" loading="lazy" class="home-design-card__image" />
    </a>
    <div class="home-design-card__main-wrapper">
        <h3 class="home-design-card__title">
            <a href="<?= $href ?>" title="<?= $title ?>">
                <?= $title ?>
            </a>
        </h3>
        <ul class="home-design-card__list">
            <li class="home-design-card__item">
                <p class="home-design-card__item-inner">
                    <span class="home-design-card__item-subtitle uppercase">Bed</span>
                    <span>
                        <?= $bedrooms ?>
                    </span>
                </p>
            </li>
            <li class="home-design-card__item">
                <p class="home-design-card__item-inner">
                    <span class="home-design-card__item-subtitle uppercase">Bath</span>
                    <span>
                        <?= $bathrooms ?>
                    </span>
                </p>
            </li>
            <li class="home-design-card__item">
                <p class="home-design-card__item-inner">
                    <span class="home-design-card__item-subtitle uppercase">SQ FT</span>
                    <span>
                        <?= $sq_ft ?>
                    </span>
                </p>
            </li>
        </ul>
        <a href="<?= $href ?>" class="home-design-card__button"
            title="Learn more about <?= $title ?> <?= $plan_type ?>">
            <span>
                <?= $plan_type ?>
            </span>
            <span class="home-design-card__arrow"></span>
        </a>
    </div>
</article>
