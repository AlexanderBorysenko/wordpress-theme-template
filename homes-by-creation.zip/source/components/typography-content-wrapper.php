<div class="typography-content-wrapper <?= $class ?>">
    <?= $content ?>
</div>
