<section class="page-hero container <?= $class ?>">
    <div class="page-hero__main pt-4 pb-4">
        <?= component('hero-title', [
            'text' => $title,
            'class' => 'page-hero__title'
        ]) ?>
        <?= component('regular-subtitle', [
            'text' => $subtitle,
            'class' => 'page-hero__subtitle'
        ]) ?>
        <?= component('primary-button', [
            'href' => carbon_get_theme_option('crb_contact_page_link'),
            'text' => 'Book consultation',
            'class' => 'page-hero__button _regular-dark'
        ]) ?>
        <?php if ($logo): ?>
            <img class="page-hero__logo" src="<?= $logo['src'] ?>" alt="<?= $logo['alt'] ?>" width="<?= $logo['width'] ?>"
                height="<?= $logo['height'] ?>" srcset="<?= $logo['srcset'] ?>" sizes="<?= $logo['sizes'] ?>" />
        <?php endif; ?>
    </div>

    <div class="page-hero__image-container">
        <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
            height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
            class="page-hero__image" />
    </div>
</section>
