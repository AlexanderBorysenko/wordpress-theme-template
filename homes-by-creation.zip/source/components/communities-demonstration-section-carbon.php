<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('communities-demonstration-section', 'Communities Demonstration')
    ->add_fields([
        Field::make('text', 'title', 'Title'),
        Field::make('text', 'subtitle', 'Subtitle'),
        Field::make('textarea', 'text', 'Text'),
        Field::make('complex', 'items', 'Items')
            ->add_fields([
                Field::make('text', 'title', 'Title'),
                Field::make('text', 'subtitle', 'Subtitle'),
                Field::make('image', 'image', 'Image'),
            ]),
        get_margin_bottom_select_field(),
        get_background_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('excerpt-view')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('communities-demonstration-section', [
            'title' => $title,
            'subtitle' => $subtitle,
            'text' => $text,
            'items' => array_map(function ($item) {
                return [
                    'title' => $item['title'],
                    'subtitle' => $item['subtitle'],
                    'image' => get_image($item['image']),
                ];
            }, $items),
            'class' => $margin_bottom . ' ' . $background,
        ]);
    });