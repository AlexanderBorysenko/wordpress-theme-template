<section class="locations-map-section pt-5-5 <?= $class ?>">
    <hgroup class="container mb-3-5">
        <?= component('decorated-pre-section-title', [
            'text' => 'Map',
            'class' => 'mb-1-5'
        ]) ?>
        <?= component('section-title', [
            'text' => 'Location our objects',
            'class' => 'lh-100'
        ]) ?>
    </hgroup>
    <img src="<?= get_template_directory_uri() ?>/images/map-placeholder.jpg" alt="Map" class="w-100" loading="lazy">
</section>
