<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('building-stages-demonstration', 'Building Stages Demonstration')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Pre Title'),
        Field::make('text', 'title', 'Title'),
        Field::make('textarea', 'text', 'Text'),
    ])
    ->add_tab('Images', [
        Field::make('media_gallery', 'images', 'Images'),
    ])
    ->add_tab('Stages', [
        Field::make('complex', 'stages', 'Stages')
            ->add_fields('stage', [
                Field::make('text', 'phase', 'Phase'),
                Field::make('text', 'title', 'Title'),
                Field::make('select', 'status', 'Status')
                    ->add_options([
                        '_upcomming' => 'Upcomming',
                        '_completed' => 'Completed',
                        '_in-process' => 'In Process',
                    ])->set_default_value('_upcomming'),
            ])->set_layout('tabbed-horizontal')->set_header_template('<%- phase %>'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('excerpt-view')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('building-stages-demonstration', [
            'pre_title' => $pre_title,
            'title' => $title,
            'text' => $text,
            'images' => array_map(function ($image) {
                return get_image($image);
            }, $images),
            'stages' => $stages,
            'class' => $margin_bottom,
        ]);
    });