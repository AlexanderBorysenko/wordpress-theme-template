<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('overview-section', 'Overview')
    ->add_fields([
        // fields for overview-section.php

        Field::make('select', 'orientation', 'Orientation')
            ->add_options([
                '_image-left' => 'Image Left',
                '_image-right' => 'Image Right',
            ]),
        Field::make('text', 'top_logo_text', 'Top Logo Text'),
        Field::make('text', 'pre_title', 'Pre Title'),
        Field::make('text', 'title', 'Title'),
        Field::make('complex', 'result_value_items', 'Result Value Items')
            ->add_fields([
                Field::make('image', 'icon', 'Icon'),
                Field::make('text', 'number', 'Number'),
                Field::make('text', 'title', 'Title'),
            ])->set_layout('tabbed-horizontal'),
        Field::make('image', 'image', 'Image'),
        Field::make('rich_text', 'slot', 'Slot'),
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('welcome-widgets-menus')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('overview-section', [
            'orientation' => $orientation,
            'title' => $title,
            'pre_title' => $pre_title,
            'top_logo_text' => $top_logo_text,
            'result_value_items' => array_map(function ($item) {
                return [
                    'title' => $item['title'],
                    'number' => $item['number'],
                    'icon' => get_image($item['icon'], 'large'),
                ];
            }, $result_value_items),
            'image' => get_image($image, 'large'),
            'slot' => apply_filters('the_content', $slot),
            'class' => $margin_bottom
        ]);
    });