<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('logos-carousel', 'Logos Carousel')
    ->add_fields([
        Field::make('complex', 'items', 'Items')
            ->add_fields([
                Field::make('image', 'image', 'Image'),
            ])->set_layout('tabbed-horizontal'),
        get_margin_bottom_select_field(),
        get_background_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('images-alt2')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('logos-carousel', [
            'items' => array_map(function ($item) {
                return [
                    'image' => get_image($item['image']),
                ];
            }, $items),
            'class' => $margin_bottom . ' ' . $background,
        ]);
    });