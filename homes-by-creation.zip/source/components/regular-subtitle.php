<p class="regular-subtitle color-primary ff-montserrat fw-500 uppercase fs-1-5 <?= $class ?>">
    <?= $text ?>
</p>
