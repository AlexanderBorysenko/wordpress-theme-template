const initCommunitiesDemonstrationSection = (): void => {
    const myImages = document.querySelectorAll<HTMLImageElement>('.communities-demonstration-section__image');
    const activeButtons = document.querySelectorAll<HTMLElement>('.communities-demonstration-section__item');

    activeButtons.forEach((button) => {
        button.addEventListener('click', handleButtonClick);
    });

    function handleButtonClick(e: Event) {
        const target = e.target as HTMLElement;
        const button = target.dataset.button;

        if (!button) return;

        const contentActive = document.querySelectorAll<HTMLElement>(`.${button}`);

        activeButtons.forEach((item) => {
            item.classList.remove('_active');
        });

        target.classList.add('_active');

        myImages.forEach((item) => {
            item.classList.remove('_active');
        });

        contentActive.forEach((item) => {
            item.classList.add('_active');
        });
    }
};

export default initCommunitiesDemonstrationSection;