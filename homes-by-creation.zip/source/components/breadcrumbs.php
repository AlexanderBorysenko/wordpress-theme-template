<?php
if (function_exists('yoast_breadcrumb')) {
    yoast_breadcrumb('<div class="container breadcrumbs-wrapper"><p id="breadcrumbs" class="breadcrumbs">', '</p></div>');
} else if (is_admin()) {
    echo '<p id="breadcrumbs" class="breadcrumbs">Yoast SEO plugin is not installed</p>';
}