<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('our-team-section', 'Our Team')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Pre Title')->set_default_value('Our Team'),
        Field::make('text', 'title', 'Title')->set_default_value('Meet the Creation Family'),
    ])
    ->add_tab('Team Members', [
        Field::make('association', 'members', 'Team Members')
            ->set_types([
                [
                    'type' => 'post',
                    'post_type' => 'team-member',
                ],
            ])
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('buddicons-buddypress-logo')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component(
            'our-team-section',
            [
                'pre_title' => $pre_title,
                'title' => $title,
                'members' => array_map(function ($item) {
                    $member = get_post($item['id']);
                    return [
                        'image' => get_image(get_post_thumbnail_id($member->ID)),
                        'name' => $member->post_title,
                        'role' => carbon_get_post_meta($member->ID, 'crb_role'),
                        'phone' => carbon_get_post_meta($member->ID, 'crb_phone'),
                        'email' => carbon_get_post_meta($member->ID, 'crb_email'),
                    ];
                }, $members),
                'class' => $margin_bottom,
            ]
        );
    });