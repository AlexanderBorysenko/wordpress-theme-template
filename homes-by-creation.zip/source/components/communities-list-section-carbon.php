<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('communities-list-section', 'Communities List')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Pre Title'),
        Field::make('text', 'title', 'Title'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_icon('location-alt')
    ->set_category('theme-blocks')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);

        $items = get_posts([
            'post_type' => 'community',
            'posts_per_page' => -1,
            'exclude' => get_current_post_id(),
        ]);

        component('communities-list-section', [
            'pre_title' => $pre_title,
            'title' => $title,
            'class' => $margin_bottom,
            'items' => array_map(function ($item) {
                return [
                    'location' => carbon_get_post_meta($item->ID, 'crb_location'),
                    'title' => $item->post_title,
                    'href' => get_permalink($item->ID),
                    'image' => get_image(get_post_thumbnail_id($item->ID)),
                    'excerpt' => $item->post_excerpt,
                ];
            }, $items),
        ]);
    });