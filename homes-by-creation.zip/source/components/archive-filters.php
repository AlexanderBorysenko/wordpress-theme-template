<form method="GET" class="archive-filters <?= $class ?>">
    <?php foreach ($taxonomies as $taxonomy): ?>
        <?php $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]); ?>
        <?= component('filter-group', [
            'title' => get_taxonomy($taxonomy)->label,
            'filters' => array_map(function ($term) use ($taxonomy) {
                        $selected = isset ($_GET[$taxonomy]) && in_array($term->slug, (array) $_GET[$taxonomy]);
                        return [
                            'taxonomy' => $taxonomy,
                            'name' => $term->name,
                            'slug' => $term->slug,
                            'selected' => $selected,
                        ];
                    }, $terms),
        ]); ?>
    <?php endforeach; ?>
</form>
