<section class="sub-hero-banner <?= $class ?>">
    <div class="container sub-hero-banner__inner">
        <div class="sub-hero-banner__main">
            <?=
                component('section-title', [
                    'text' => $title,
                    'class' => 'sub-hero-banner__title mb-1-5 lh-100'
                ]);
            ?>
            <div class="typography-content-wrapper">
                <?= $content ?>
            </div>
        </div>
        <div class="sub-hero-banner__image-container">
            <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
                class="sub-hero-banner__image" loading="eager" />
        </div>
    </div>
</section>
