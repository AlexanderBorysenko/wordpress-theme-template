<div class="megamenu <?= $class ?> ff-montserrat" id="<?= $id ?>" aria-labelledby="<?= $id ?>-toggle-button">
    <div class="container container-tw-drop grid">
        <nav class="megamenu__body grid-col-start-3 grid-sdw-col-start-1 grid-col-end-13">
            <?= $slot ?>
        </nav>
    </div>
</div>
