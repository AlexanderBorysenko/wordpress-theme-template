<a href="<?= $href ?>" class="community-link-card <?= $class ?>" style="background-image: url(<?= $image ?>)">
    <span class="community-link-card__title">
        <?= $title ?>
    </span>
    <?php if ($location): ?>
        <span class="community-link-card__text">
            <?= $location ?>
        </span>
    <?php endif; ?>
</a>
