<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('building-sales-section', 'Building Sales')
    ->add_tab('Gallery', [
        Field::make('media_gallery', 'images', 'Gallery')
    ])
    ->add_tab('Sales', [
        Field::make('association', 'sales', 'Sales')
            ->set_types([
                [
                    'type' => 'post',
                    'post_type' => 'team-member'
                ]
            ])
            ->set_max(1)
    ])
    // margin_bottom
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('screenoptions')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        $salesId = $sales[0]['id'];
        $sales = [
            'name' => get_the_title($salesId),
            'role' => carbon_get_post_meta($salesId, 'crb_role'),
            'phone' => carbon_get_post_meta($salesId, 'crb_phone'),
            'email' => carbon_get_post_meta($salesId, 'crb_email'),
            'image' => get_image(get_post_thumbnail_id($salesId))
        ];
        $images = array_map(function ($image) {
            return get_image($image);
        }, $images);

        component('building-sales-section', [
            'images' => $images,
            'sales' => $sales,
            'class' => $margin_bottom
        ]);
    });