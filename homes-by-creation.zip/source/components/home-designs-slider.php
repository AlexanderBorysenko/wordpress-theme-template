<div class="home-designs-slider">
    <ul class="swiper-wrapper home-designs-slider__swiper-wrapper">
        <?php
        $recent_home_designs = new WP_Query([
            'post_type' => 'home-design',
            'posts_per_page' => 8,
            'orderby' => 'date',
            'order' => 'DESC'
        ]);
        if ($recent_home_designs->have_posts()):
            while ($recent_home_designs->have_posts()):
                $recent_home_designs->the_post();
                ?>
                <li class="home-designs-slider__item swiper-slide">
                    <?= component('home-design-card', [
                        'image' => get_image(get_post_thumbnail_id()),
                        'title' => get_the_title(),
                        'bedrooms' => carbon_get_the_post_meta('crb_bedrooms'),
                        'bathrooms' => carbon_get_the_post_meta('crb_bathrooms'),
                        'sq_ft' => carbon_get_the_post_meta('crb_sq_ft'),
                        'plan_type' => carbon_get_the_post_meta('crb_plan_type'),
                        'href' => get_the_permalink()
                    ]) ?>
                </li>
            <?php endwhile;
        endif;
        wp_reset_postdata();
        ?>
    </ul>
</div>
