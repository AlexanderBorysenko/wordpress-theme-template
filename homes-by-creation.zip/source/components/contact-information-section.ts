export const initContactInformationSection = () => {
    const contactInformationSections = document.querySelectorAll<HTMLElement>('.contact-information-section');

    // init each section -> add event listener to each button, toggle active class on elements with data-location attribute matching the <let currentLocation>. Set default location to first button with _active class
    contactInformationSections.forEach(contactInformationSection => {
        const locationButtons = contactInformationSection.querySelectorAll<HTMLButtonElement>('.contact-information-section__location-toggle-button');

        let currentLocation = locationButtons[0].dataset.location;
        const itemsWithDataLocation = contactInformationSection.querySelectorAll<HTMLElement>('[data-location]');

        locationButtons.forEach(locationButton => {
            locationButton.addEventListener('click', () => {
                currentLocation = locationButton.dataset.location;

                itemsWithDataLocation.forEach(item => {
                    item.classList.remove('_active');
                    if (item.dataset.location === currentLocation) {
                        item.classList.add('_active');
                    }
                });
            });
        });
    });
}