<nav class="table-of-contents <?= $class ?>" itemscope itemtype="http://schema.org/PublicationIssue">
    <h2 class="ff-montserrat fw-700 uppercase mb-0-75 fs-1">Table of content</h2>
    <div class="table-of-contents__list-wrapper">
        <ol class="table-of-contents__list">
            <?php foreach ($items as $key => $header): ?>
                <li class="table-of-contents__item <?= $key == 0 ? '_active' : '' ?>" data-anchor="<?= $header['id'] ?>"
                    itemprop="hasPart" itemscope itemtype="http://schema.org/Article">
                    <a href="#<?= $header['id'] ?>" class="table-of-contents__item-link">
                        <?= $header['title'] ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ol>
    </div>
</nav>
