<article class="blog-post-card <?= $class ?>">
    <div class="blog-post-card__main">
        <h3 class="blog-post-card__title">
            <a href="<?= $href ?>">
                <?= $title ?>
            </a>
        </h3>
        <p class="blog-post-card__excerpt">
            <?= $excerpt ?>
        </p>
        <a href="<?= $href ?>" title="<?= $title ?>" class="blog-post-card__read-more-link">
            Read More >
        </a>
    </div>
    <a class="blog-post-card__image" href="<?= $href ?>">
        <img src="<?= $image['src'] ?>" alt="<?= $title ?>" width="<?= $image['width'] ?>"
            height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>" />
    </a>
</article>
