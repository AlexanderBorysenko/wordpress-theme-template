<section class="pt-5-5 pb-4 communities-list-section container
has-semi-grey-background <?= $class ?>">
    <div class="flex-row justify-between gap-2 align-end mb-3-5">
        <hgroup>
            <?= component('decorated-pre-section-title', [
                'text' => $pre_title,
                'class' => 'mb-1-5 communities-list-section__pre-title fw-600'
            ]) ?>
            <?= component('section-title', [
                'text' => $title,
                'class' => 'home-communities-list-section__title lh-100 uppercase ff-montserrat fw-700'
            ]) ?>
        </hgroup>
        <!-- <primary-button href="#" class="_light-bordered home-communities-list-section__button">
            view all Gallery
        </primary-button> -->
    </div>

    <ul class="communities-list-section__list">
        <?php foreach ($items as $item): ?>
            <li class="communities-list-section__item">
                <?= component('community-card', $item) ?>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
