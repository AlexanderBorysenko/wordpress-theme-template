<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('contact-us-section', 'Contact Us')
    ->add_fields([
        Field::make('text', 'title', 'Title')->set_default_value('Build your<br/> legacy with us.'),
        Field::make('textarea', 'text', 'Text')->set_default_value('Contact the Homes by Creation team about how we can help build your future.'),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('email-alt')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('contact-us-section', [
            'title' => $title,
            'text' => $text,
        ]);
    });