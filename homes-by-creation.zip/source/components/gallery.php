<?php
if (!isset ($items)) {
    $items = carbon_get_theme_option('crb_gallery_portfolio');
    if (isset ($limit)) {
        $items = array_slice($items, 0, $limit);
    }

    $items = array_map(function ($item) {
        return get_image($item);
    }, $items);
}
?>
<ul class="gallery <?= $class ?>">
    <?php
    foreach ($items as $image):
        ?>
        <li class="gallery-item" data-full-image="<?= $image['full'] ?>">
            <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                height="<?= $image['height'] ?>" loading="lazy" srcset="<?= $image['srcset'] ?>"
                class="gallery-item__thumbnail">
            <?php
    endforeach;
    ?>
</ul>
