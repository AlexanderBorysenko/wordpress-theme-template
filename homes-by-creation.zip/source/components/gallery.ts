import { showImageViewModal } from "./image-view-modal";

export const initGallery = () => {
    const galleryItems = document.querySelectorAll<HTMLElement>('.gallery-item');

    galleryItems.forEach((item) => {
        item.addEventListener('click', (e) => {
            const target = e.target as HTMLElement;
            const src = target.getAttribute('data-full-image');
            if (!src) return;

            showImageViewModal(src);
        });
    });
}