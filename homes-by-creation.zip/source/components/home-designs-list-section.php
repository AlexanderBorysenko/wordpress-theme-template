<section class="home-designs-list-section container mb-7-75">
    <div class="flex-row gap-2 justify-between align-end mb-2-5 <?= $class ?>">
        <hgroup>
            <?= component('section-title', [
                'text' => $title,
                'class' => 'lh-100 uppercase fs-2-5 fw-700 ff-montserrat'
            ]) ?>
        </hgroup>
        <?= component('primary-button', [
            'href' => get_post_type_archive_link('home-design'),
            'text' => 'View Floor Plans',
            'class' => 'home-designs-list-section__button _light-bordered'
        ]) ?>
    </div>

    <ul class="home-designs-list-section__list grid">
        <?php foreach ($items as $item): ?>
            <?php
            if (is_object($item) && $item instanceof WP_Post)
                $home_design = $item;
            else if (isset ($item['id']))
                $home_design = get_post($item['id']);
            else
                continue;
            ?>
            <li class="home-designs-list-section__item grid-col-3 grid-tw-col-6 grid-mw-col-12">
                <?=
                    component('home-design-card', [
                        'title' => $home_design->post_title,
                        'image' => get_image(
                            get_post_thumbnail_id($home_design->ID)
                        ),
                        'href' => get_permalink($home_design->ID),
                        'bedrooms' => carbon_get_post_meta($home_design->ID, 'crb_bedrooms'),
                        'bathrooms' => carbon_get_post_meta($home_design->ID, 'crb_bathrooms'),
                        'sq_ft' => carbon_get_post_meta($home_design->ID, 'crb_sq_ft'),
                        'class' => '_semi-gray-background'
                    ])
                    ?>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
