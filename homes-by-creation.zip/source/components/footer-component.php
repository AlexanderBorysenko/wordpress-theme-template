<footer class="footer">
    <div class="container footer__inner">
        <div class="footer__top">
            <a href="/" class="footer__logo">
                <img src="<?= get_template_directory_uri() ?>/images/logo-white.svg" alt="Homes By Creation" />
            </a>
            <?= component('footer-socials', [
                'class' => 'footer__socials'
            ]) ?>
            <address class="footer__address">
                <?= carbon_get_theme_option('crb_head_office_address_first_line') ?>
                <br />
                <span class="color-grey">
                    <?= carbon_get_theme_option('crb_head_office_address_second_line') ?>
                </span>
            </address>
            <a class="footer__phone" href="tel:<?= carbon_get_theme_option('crb_phone') ?>">
                <?= carbon_get_theme_option('crb_phone') ?> <br />
                <span class="color-grey fw-600">Call us</span>
            </a>
            <?=
                component(
                    'primary-button',
                    [
                        'class' => '_full-dark footer__up-button',
                        'href' => '#',
                        'text' => 'Up',
                    ]
                )
                ?>
        </div>
        <?= component('footer-menu', [
            'class' => 'footer__menu'
        ]) ?>
        <div class="flex-row justify-between align-center pb-2 uppercase fs-0-75 fw-500">
            <p class="color-dark-grey">
                ©
                <?= date('Y') ?> Homes by Creation | All Rights Reserved |
            </p>
            <p class="flex-row gap-0-75">
                <a class="color-white underline--on-hover" href="/sitemap.xml" target="_blank">Sitemap</a>
                <a class="color-white underline--on-hover" href="/privacy-policy" target="_blank">Privacy Policy</a>
            </p>
        </div>
    </div>
</footer>
