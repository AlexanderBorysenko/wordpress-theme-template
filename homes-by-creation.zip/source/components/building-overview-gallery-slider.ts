import Swiper from 'swiper';
import { Navigation, Pagination } from 'swiper/modules';

// building-overview-gallery-slider
const initQBuildingOverviwGallerySlider = () => {
    const sliders = document.querySelectorAll<HTMLElement>('.building-overview-gallery-slider');


    sliders.forEach(carousel => {
        const prevButton = carousel.querySelector<HTMLElement>('.building-overview-gallery-slider__swiper-button-prev');
        const nextButton = carousel.querySelector<HTMLElement>('.building-overview-gallery-slider__swiper-button-next');
        const pagination = carousel.querySelector<HTMLElement>('.building-overview-gallery-slider__swiper-pagination');
        const slider = carousel.querySelector<HTMLElement>('.building-overview-gallery-slider__swiper-container');
        new Swiper(slider, {
            loop: true,
            modules: [Navigation, Pagination],
            navigation: {
                nextEl: nextButton,
                prevEl: prevButton
            },
            pagination: {
                el: pagination,
                clickable: false,
                dynamicBullets: false
            }
        });
    });
}

export default initQBuildingOverviwGallerySlider;