<a href="<?= $href ?? '' ?>" target="<?= $target ?? '' ?>" rel="<?= $rel ?? '' ?>"
    class="primary-button <?= $class ?? '' ?>" type="button" title="<?= wp_strip_all_tags($text) ?>">
    <span class="primary-button__body">
        <span class="primary-button__text">
            <?= $text ?? '' ?>
        </span>
    </span>
</a>
