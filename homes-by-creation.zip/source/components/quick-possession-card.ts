const quickPossessionCards = document.querySelectorAll('.quick-possession-card')

function redirectToQuickPossession(): void {
    const link = document.querySelector<HTMLLinkElement>('.quick-possession__link');

    window.location.href = link?.href || '';
}

quickPossessionCards.forEach((card) => {
    card.addEventListener('click', redirectToQuickPossession);
})