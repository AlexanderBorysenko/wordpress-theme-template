import { fadeToggleModal, addActiveModalWindowChangeListener } from '../scripts/modal';

const initBaseMegaMenuComponent = (): void => {
    const megaMenus = document.querySelectorAll<HTMLElement>('.megamenu');
    megaMenus.forEach((megaMenu) => {
        const id = megaMenu.id;
        if (!id) return;

        megaMenu.addEventListener('click', (e: Event) => {
            if (e.target === megaMenu) fadeToggleModal(id);
        });

        const togglers = document.querySelectorAll<HTMLElement>(`[aria-controls="${id}"]`);
        togglers.forEach((toggler) => {
            addActiveModalWindowChangeListener(newId => {
                toggler.classList.toggle('_active', id === newId);
            });
            toggler.addEventListener('click', (e) => {
                e.preventDefault();
                fadeToggleModal(id);
            });
        })
    })
}

export default initBaseMegaMenuComponent;