const initMobileMegamenu = () => {
    // find .toggle-submenu items, add click event listener -> toggle class ._active on the button->parent->.mobile-megamenu__submenu

    const toggleSubmenuButtons = document.querySelectorAll('.mobile-megamenu__link');

    toggleSubmenuButtons.forEach((button) => {
        button.addEventListener('click', (e: Event) => {
            e.preventDefault();
            const submenu = button.parentElement?.querySelector('.mobile-megamenu__submenu');

            if (submenu) {
                submenu.classList.toggle('_active');
                button.classList.toggle('_active');
            }
        });
    });
};

export default initMobileMegamenu;
