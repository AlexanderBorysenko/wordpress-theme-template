<div class="building-overview-gallery-slider <?= $class ?>">
    <div class="building-overview-gallery-slider__swiper-container">
        <ul class="building-overview-gallery-slider__list swiper-wrapper">
            <?php foreach ($images as $image): ?>
                <li class="building-overview-gallery-slider__item swiper-slide">
                    <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                        height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>" />
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="building-overview-gallery-slider__swiper-button-next">
        <svg>
            <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#slider-chevron-right"></use>
        </svg>
    </div>
    <div class="building-overview-gallery-slider__swiper-button-prev">
        <svg>
            <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#slider-chevron-left"></use>
        </svg>
    </div>
    <div class="building-overview-gallery-slider__swiper-pagination"></div>
</div>
