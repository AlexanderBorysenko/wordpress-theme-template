<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('contact-information-section', 'Contact Information')
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('index-card')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('contact-information-section', [
            'class' => $margin_bottom,
        ]);
    });