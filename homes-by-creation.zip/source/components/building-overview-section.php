<section class="building-overview-section has-semi-grey-background <?= $class ?>">
    <div class="container building-overview-section__inner">
        <div class="building-overview-section__main">
            <div class="flex-row gap-1 align-center justify-between mb-1-5">
                <img class="building-overview-section__logo" src="<?= $logo['src'] ?>" alt="<?= $logo['alt'] ?>"
                    width="<?= $logo['width'] ?>" height="<?= $logo['height'] ?>" srcset="<?= $logo['srcset'] ?>"
                    sizes="<?= $logo['sizes'] ?>" />
                <?php if ($top_price || $bottom_price): ?>
                    <p class="building-overview-section__prices ff-montserrat">
                        <span class="block fs-1-5 fw-700 mb-0-5">
                            <?= $top_price ?>
                        </span>
                        <span class="block">
                            <?= $bottom_price ?>
                        </span>
                    </p>
                <?php endif; ?>
            </div>
            <?= component('hero-title', [
                'text' => $title,
                'class' => 'mb-1'
            ]) ?>
            <?php if ($subtitle): ?>
                <?= component('regular-subtitle', [
                    'text' => $subtitle,
                    'class' => 'mb-1'
                ]) ?>
            <?php endif; ?>
            <div class="typography-content-wrapper mb-3">
                <?= $content ?>
            </div>
            <?php
            $bedrooms = carbon_get_the_post_meta('crb_bedrooms');
            $bathrooms = carbon_get_the_post_meta('crb_bathrooms');
            $sq_ft = carbon_get_the_post_meta('crb_sq_ft');
            ?>
            <?= component('quick-possession-metriks-list', [
                'class' => 'mb-3',
                'bedrooms' => $bedrooms ? $bedrooms : '[[Bedrooms]]',
                'bathrooms' => $bathrooms ? $bathrooms : '[[Bathrooms]]',
                'sq_ft' => $sq_ft ? $sq_ft : '[[Sq Ft]]'
            ]) ?>
            <div class="building-overview-section__buttons">
                <?=
                    component(
                        'primary-button',
                        [
                            'class' => '_regular-dark',
                            'href' => '#contact-us-section',
                            'text' => 'Schedule a viewing',
                        ]
                    );
                ?>
                <?php
                if ($floor_plan):
                    component(
                        'primary-button',
                        [
                            'class' => '_light-bordered',
                            'href' => $floor_plan,
                            'text' => '<strong>PDF</strong> View Floor Plan',
                        ]
                    );
                endif;
                ?>
            </div>
        </div>
        <?php if (count($images)): ?>
            <?=
                component('building-overview-gallery-slider', [
                    'images' => $images,
                    'class' => 'building-overview-section__slider'
                ]);
            ?>
        <?php endif; ?>
    </div>
</section>
