import { fadeIn, fadeOut } from "../scripts/fadeEffect"

let imageModal: HTMLElement | null = null;
let imageModalImage: HTMLElement | null = null;

function initImageViewModal() {
    imageModal = document.querySelector<HTMLElement>('.image-view-modal');
    if (!imageModal) return;

    imageModalImage = imageModal.querySelector<HTMLElement>('.image-view-modal__image');

    const closeButton = imageModal.querySelector<HTMLElement>('.image-view-modal__close-button');

    const contentWrapper = imageModal.querySelector<HTMLElement>('.image-view-modal__content');
    contentWrapper?.addEventListener('click', (e) => {
        if (e.target === contentWrapper) closeImageViewModal();
    });

    if (!closeButton) return;
    closeButton.addEventListener('click', () => {
        closeImageViewModal();
    });
}

function closeImageViewModal() {
    fadeOut(imageModal!, {
        onEnd: () => {
            imageModalImage?.setAttribute('src', '');
        }
    });
}

function showImageViewModal(imageSrc: string) {
    imageModalImage?.setAttribute('src', imageSrc);
    fadeIn(imageModal!);
}

export { showImageViewModal, initImageViewModal };