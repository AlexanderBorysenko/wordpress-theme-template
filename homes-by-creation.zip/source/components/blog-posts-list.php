<ul class="blog-posts-list grid gap-1 <?= $class ?>">
    <?php foreach ($items as $item):
        if (is_object($item) && $item instanceof WP_Post)
            $post = $item;
        else if (isset ($item['id']))
            $post = get_post($item['id']);
        else
            continue;
        ?>
        <li class="grid-col-3 grid-sdw-col-4 grid-tw-col-6 grid-mw-col-12 blog-posts-list__item">
            <?=
                component('blog-post-card', [
                    'title' => get_the_title($post->ID),
                    'image' => get_image(
                        get_post_thumbnail_id(
                            $post->ID
                        )
                    ),
                    'href' => get_permalink($post->ID),
                    'excerpt' => get_the_excerpt($post->ID),
                ]);
            ?>
        </li>
    <?php endforeach; ?>
</ul>
