<div class="simple-gallery-slider <?= $class ?>">
    <ul class="simple-gallery-slider__swiper-wrapper swiper-wrapper">
        <?php foreach ($items as $image): ?>
            <li class="simple-gallery-slider__item swiper-slide">
                <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                    height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
                    loading="lazy" />
            </li>
        <?php endforeach; ?>
    </ul>
    <div class="simple-gallery-slider__swiper-button-next"></div>
    <div class="simple-gallery-slider__swiper-button-prev"></div>
    <div class="simple-gallery-slider__swiper-pagination"></div>
</div>
