<section class="blog-post-hero has-semi-grey-background">
    <div class="container blog-post-hero__inner">
        <div class="blog-post-hero__main">
            <?=
                component('post-publish-info', [
                    'author' => $author,
                    'date' => $date,
                    'class' => 'blog-post-hero__publish-info'
                ]);
            ?>
            <?=
                component('hero-title', [
                    'text' => $title,
                    'class' => 'blog-post-hero__title mb-2-5'
                ]);
            ?>
        </div>
        <div class="blog-post-hero__image-wrapper">
            <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
                class="blog-post-hero__image" loading="eager" />
        </div>
    </div>
</section>
