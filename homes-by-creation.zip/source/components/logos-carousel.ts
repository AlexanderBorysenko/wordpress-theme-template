import Swiper from 'swiper';
import { Autoplay } from 'swiper/modules';


const initLogosCarousel = () => {
    // .logos-carousel infinite auto slider
    const carousels = document.querySelectorAll<HTMLElement>('.logos-carousel');

    carousels.forEach(carousel => {

        // get .logos-carousel__item's, duplicate them until .logos-carousel__swiper-wrapper's width is greater than 200vw
        const carouselItems = carousel.querySelectorAll<HTMLElement>('.logos-carousel__item');
        const carouselWrapper = carousel.querySelector<HTMLElement>('.logos-carousel__swiper-wrapper');

        if (!carouselWrapper) return;
        let wrapperWidth = 0;
        carouselItems.forEach(item => {
            wrapperWidth += item.clientWidth;
        });

        for (let index = 0; index < Math.floor(window.innerWidth * 3 / wrapperWidth); index++) {
            carouselItems.forEach(item => {
                const clone = item.cloneNode(true) as HTMLElement;
                carouselWrapper.appendChild(clone);
            });
        }

        new Swiper(carousel, {
            slidesPerView: 'auto',
            // centeredSlides: true,
            spaceBetween: 16,
            modules: [Autoplay],
            loop: true,
            centeredSlides: true,
            speed: 5000,
            allowTouchMove: false,
            autoplay: {
                delay: 0,
                disableOnInteraction: false,
                pauseOnMouseEnter: false,
            },
            breakpoints: {
                768: {
                    spaceBetween: 24,
                },
                1024: {
                    spaceBetween: 32,
                },
                1280: {
                    spaceBetween: 53,
                },
            }
        });
    });

}

export default initLogosCarousel