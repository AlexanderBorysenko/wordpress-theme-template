<nav class="header-navigation <?= $class ?>">
    <ul class="header-navigation__list">
        <li class="header-navigation__item">
            <a href="#what-we-build-megamenu" id="what-we-build-megamenu-toggle-button" aria-haspopup="true"
                aria-controls="what-we-build-megamenu" class="header-navigation__link toggle-megamenu">
                What We build
            </a>
        </li>
        <li class="header-navigation__item">
            <a href="#quick-possession-megamenu" id="quick-possession-megamenu-toggle-button" aria-haspopup="true"
                aria-controls="quick-possession-megamenu" class="header-navigation__link toggle-megamenu">
                Quick Posession
            </a>
        </li>
        <li class="header-navigation__item">
            <a href="#company-submenu" id="company-submenu-toggle-button" aria-haspopup="true"
                aria-controls="company-submenu" class="header-navigation__link toggle-submenu">
                Company
            </a>
            <?= component(
                'header-menu-column-list',
                [
                    'items' => carbon_get_theme_option('crb_company_navigation_menu'),
                    'class' => 'header-navigation__submenu',
                    'id' => 'company-submenu',
                ]
            ) ?>
        </li>
        <li class="header-navigation__item">
            <a href="/contact-us.html" class="header-navigation__link">
                Contact Us
            </a>
        </li>
    </ul>
</nav>
