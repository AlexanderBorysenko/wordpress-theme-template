<article class="community-card">
    <div class="community-card__main">
        <div class="community-card__main-container">
            <?= component('decorated-pre-section-title', [
                'text' => $location,
                'class' => 'community-card__decorated'
            ]) ?>
            <h3 class="community-card__title">
                <?= $title ?>
            </h3>
            <p>
                <?= $excerpt ?>
            </p>
        </div>
        <!-- <primary-button class="community-card__button _regular-dark">
            Learn more
        </primary-button> -->
        <?= component('primary-button', [
            'href' => $href,
            'text' => 'Learn more',
            'class' => 'community-card__button _regular-dark'
        ]) ?>
    </div>
    <div class="community-card__image">
        <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
            height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
            loading="lazy" />
    </div>
</article>
