<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('instagram-section', 'Instagram')
    ->add_fields([
        Field::make('complex', 'items', 'Instagram Items')
            ->add_fields('item', 'Item', [
                Field::make('image', 'image', 'Image'),
                Field::make('text', 'link', 'Link'),
            ])
            ->set_layout('tabbed-horizontal')
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('instagram')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('instagram-section', [
            // get_image on each item
            'items' => array_map(function ($item) {
                return [
                    'image' => get_image($item['image']),
                    'link' => $item['link']
                ];
            }, $items)
        ]);
    });