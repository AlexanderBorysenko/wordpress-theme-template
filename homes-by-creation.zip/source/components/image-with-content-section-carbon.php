<?php

use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('image-with-content-section', 'Image with Content')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Pre Title'),
        Field::make('text', 'title', 'Title'),
        Field::make('rich_text', 'content', 'Content'),
        Field::make('checkbox', 'content_larger_typography', 'Make Larger Typography'),

        Field::make('image', 'image', 'Image'),
    ])
    ->add_tab('Layouting', [
        Field::make('select', 'orientation', 'Orientation')
            ->add_options([
                '_image-right' => 'Image Right',
                '_image-left' => 'Image Left',
            ]),
        get_padding_top_select_field(),
        get_padding_bottom_select_field(),
        get_margin_bottom_select_field(),
    ])
    ->add_tab('Styling', [
        get_background_select_field('background', 'Section Background'),
        get_background_select_field('inner_background', 'Inner Background'),
        Field::make('checkbox', 'has_gray_decoration', 'Has Gray Decoration'),
    ])

    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('embed-photo')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('image-with-content-section', [
            'pre_title' => $pre_title,
            'title' => $title,
            'content' => apply_filters('the_content', $content),
            'image' => get_image($image),

            'class' => $margin_bottom . ' ' . $background . ' ' . $orientation . ' ' . ($has_gray_decoration ? '_has-gray-decoration' : ''),
            'inner_class' => $inner_background . ' ' . $padding_bottom . ' ' . $padding_top . ' ',
            'content_class' => $content_larger_typography ? '_larger-typography' : '',
        ]);
    });