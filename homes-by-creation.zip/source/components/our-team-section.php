<section class="our-team-section <?= $class ?>">
    <div class="container">
        <hgroup class="mb-3-5">
            <?= component('decorated-pre-section-title', [
                'text' => $pre_title,
                'class' => 'mb-1-5'
            ]) ?>
            <?= component('section-title', [
                'text' => $title,
                'class' => 'lh-100'
            ]) ?>
        </hgroup>
        <?php foreach ($members as $member): ?>
            <?= component(
                'team-member-wide-card',
                $member
            ) ?>
        <?php endforeach; ?>
    </div>
</section>
