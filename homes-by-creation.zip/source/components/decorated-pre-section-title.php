<p class="decorated-pre-section-title <?= $class ?>">
    <?= $text ?>
</p>
