<h2 class="section-title ff-montserrat fs-2-5 fw-700 uppercase <?= $class ?>">
    <?= $text ?>
</h2>
