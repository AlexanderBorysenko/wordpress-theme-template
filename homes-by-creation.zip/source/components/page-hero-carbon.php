<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('page-hero', 'Page Hero')
    ->add_tab('Content', [
        Field::make('text', 'title', 'Title'),
        Field::make('text', 'subtitle', 'Subtitle'),
        Field::make('image', 'image', 'Image'),
        Field::make('image', 'logo', 'Logo'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('heading')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('page-hero', [
            'title' => $title,
            'subtitle' => $subtitle,
            'logo' => get_image($logo),
            'image' => get_image($image),
            'class' => $margin_bottom,
        ]);
    });