<section class="instagram-section <?= $class ?>">
    <hgroup class="mb-3-5 container">
        <?=
            component('decorated-pre-section-title', [
                'text' => 'instagram',
                'class' => 'mb-1-5 _instagram-icon'
            ])
            ?>
        <?=
            component('section-title', [
                'text' => 'Follow us <a href="' . carbon_get_theme_option('crb_instagram_link') . '" target="_blank" rel="noopener noreferrer nofollow">' . carbon_get_theme_option('crb_instagram_name') . '</a>',
                'class' => 'lh-100'
            ]);
        ?>
    </hgroup>
    <ul class="grid instagram-section__items extra-large-container">
        <?php foreach ($items as $item): ?>
            <?php if ($item['image']): ?>
                <li class="instagram-section__item grid-col-3 grid-mw-col-6">
                    <a class="instagram-section__item-inner" href="<?= $item['link'] ?>" target="_blank"
                        rel="noopener noreferrer nofollow">
                        <img src="<?= $item['image']['src'] ?>" alt="<?= $item['image']['alt'] ?>"
                            width="<?= $item['image']['width'] ?>" height="<?= $item['image']['height'] ?>"
                            srcset="<?= $item['image']['srcset'] ?>" class="instagram-section__image" />
                    </a>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
</section>
