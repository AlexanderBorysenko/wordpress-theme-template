<section class="quick-possessions-list-section container mb-5-5 <?= $class ?>">
    <div class="flex-row justify-between gap-2 align-end mb-2-5">
        <?= component('section-title', [
            'text' => $title,
            'class' => 'quick-possessions-list-section__title fs-2-5 lh-100 uppercase ff-montserrat fw-700'
        ]) ?>
        <?= component('primary-button', [
            'href' => get_post_type_archive_link('quick-possession'),
            'text' => 'All Quick possessions',
            'class' => 'quick-possessions-list-section__button _light-bordered'
        ]) ?>
    </div>
    <ul class="quick-possessions-list-section__list grid gap-1">
        <?php foreach ($items as $item):
            if (is_object($item) && $item instanceof WP_Post)
                $quick_possession = $item;
            else if (isset ($item['id']))
                $quick_possession = get_post($item['id']);
            else
                continue;
            ?>
            <li class="grid-col-4 grid-tw-col-6 grid-mw-col-12 quick-possessions-list-section__item">
                <?=
                    component('quick-possession-card', [
                        'title' => $quick_possession->post_title,
                        'image' => get_image(
                            get_post_thumbnail_id($quick_possession->ID)
                        ),
                        'href' => get_permalink($quick_possession->ID),
                        'bedrooms' => carbon_get_post_meta($quick_possession->ID, 'crb_bedrooms'),
                        'bathrooms' => carbon_get_post_meta($quick_possession->ID, 'crb_bathrooms'),
                        'sq_ft' => carbon_get_post_meta($quick_possession->ID, 'crb_sq_ft'),
                        'is_available' => carbon_get_post_meta($quick_possession->ID, 'crb_is_available'),
                        'class' => '
                    _archive-type'
                    ])
                    ?>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
