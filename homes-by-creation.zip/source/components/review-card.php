<article class="review-card">
    <div class="review-card__inner">
        <h3 class="review-card__author">
            <?= $author ?>
        </h3>
        <p class="review-card__text">
            <?= $text ?>
        </p>
        <p class="review-card__rating">
            <span class="review-card__stars">
                <?php for ($i = 0; $i < $rating; $i++): ?>
                    <svg class="review-card__star">
                        <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#rating-star" />
                    </svg>
                <?php endfor; ?>
            </span>
            <span class="review-card__mark">
                <?= $rating_text ?>
            </span>
        </p>
    </div>
</article>
