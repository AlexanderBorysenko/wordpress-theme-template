<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('home-designs-list-section', 'Home Designs List')
    ->add_tab('Conent', [
        Field::make('text', 'title', 'Title'),
        Field::make('association', 'home_designs', 'Home Designs')
            ->set_types(
                array(
                    array(
                        'type' => 'post',
                        'post_type' => 'home-design',
                    ),
                )
            ),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('admin-multisite')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('home-designs-list-section', [
            'title' => $title,
            'items' => array_map(function ($item) {
                return get_post($item['id']);
            }, $home_designs),
            'class' => $margin_bottom,
        ]);
    });