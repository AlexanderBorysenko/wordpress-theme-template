<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('home-hero', 'Home Hero')
    ->add_fields([
        Field::make('text', 'title', 'Title'),
        Field::make('text', 'subtitle', 'Subtitle'),
        Field::make('textarea', 'text', 'Text'),
        Field::make('image', 'image', 'Image'),
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('heading')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('home-hero', [
            'title' => $title,
            'subtitle' => $subtitle,
            'text' => $text,
            'image' => get_image($image, 'large'),
            'class' => $margin_bottom
        ]);
    });