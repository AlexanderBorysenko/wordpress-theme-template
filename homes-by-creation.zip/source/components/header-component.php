<header class="header ff-montserrat">
    <div class="container header__inner">
        <a href="/" class="header__logo">
            <img src="<?= get_template_directory_uri() ?>/images/header-full-logo.svg" alt="Logo"
                class="header__logo-image" loading="eager">
        </a>
        <?= component(
            'header-navigation',
            [
                'class' => 'header__navigation',
            ]
        ) ?>
        <address class="header__address">
            <?= carbon_get_theme_option('crb_head_office_address_first_line') ?>
            <br />
            <span class="color-grey">
                <?= carbon_get_theme_option('crb_head_office_address_second_line') ?>
            </span>
        </address>
        <?=
            component(
                'primary-button',
                [
                    'class' => '_regular-dark header__button',
                    'href' => 'tel:' . carbon_get_theme_option('crb_phone'),
                    'text' => carbon_get_theme_option('crb_phone'),
                ]
            );
        ?>
        <?= component(
            'mobile-megamenu-toggle-button',
            [
                'class' => 'header__mobile-megamenu-toggle-button',
            ]
        ) ?>
    </div>
</header>
