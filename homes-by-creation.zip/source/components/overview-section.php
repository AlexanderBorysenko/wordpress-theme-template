<section class="overview-section container <?= $orientation ? $orientation : '_image-left' ?> <?= $class ?>">
    <div class="overview-section-information">
        <?php if ($top_logo_text): ?>
            <p class="overview-section-information__logo uppercase lh-122 fw-600 ff-montserrat">
                <?= $top_logo_text ?>
            </p>
        <?php endif; ?>
        <?php if ($pre_title):
            component(
                'decorated-pre-section-title',
                [
                    'text' => $pre_title,
                ]
            );
        endif; ?>
        <?php if ($title):
            component(
                'section-title',
                [
                    'class' => 'overview-section__title mb-2',
                    'text' => $title,
                ]
            );
        endif; ?>

        <div class="overview-section-information__content typography-content-wrapper">
            <?= $slot ?? '' ?>
        </div>
    </div>
    <div class="overview-section__main">
        <ul class="overview-section-result-values">
            <?php
            foreach ($result_value_items as $result_value):
                ?>
                <li class="overview-section-result-values__item">
                    <?php $icon = $result_value['icon']; ?>
                    <?php if ($icon): ?>
                        <img src="<?= $icon['src'] ?>" alt="<?= $result_value['title'] ?>" width="<?= $icon['width'] ?>"
                            height="<?= $icon['height'] ?>" srcset="<?= $icon['srcset'] ?>" loading="lazy" />
                    <?php endif; ?>
                    <span class="overview-section-result-values__item-number">
                        <?= $result_value['number'] ?>
                    </span>
                    <span class="overview-section-result-values__item-text">
                        <?= $result_value['title'] ?>
                    </span>
                </li>
                <?php
            endforeach;
            ?>
        </ul>
        <div class="overview-section__image-container">
            <img class="overview-section__image" src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>"
                width="<?= $image['width'] ?>" height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>"
                loading="lazy" />
            <div class="overview-section__image-decorations"></div>
        </div>
    </div>
</section>
