<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('gallery-preview-section', 'Gallery Preview')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Pre Title')->set_default_value('Gallery'),
        Field::make('text', 'title', 'Title')->set_default_value('Our Portfolio'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('format-gallery')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('gallery-preview-section', [
            'class' => $margin_bottom,
            'pre_title' => $pre_title,
            'title' => $title,
        ]);
    });