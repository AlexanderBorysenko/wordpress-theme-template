<div class="container blog-post-content grid gap-1">
    <div class="blog-post-content__main typography-content-wrapper grid-col-8 grid-tw-col-12">
        <?= the_content() ?>
    </div>
    <div class="grid-col-4 blog-post-content__aside grid-tw-col-12">
        <?php
        global $tableOfContentsData;
        component('table-of-contents', [
            'class' => '',
            'items' => $tableOfContentsData
        ]) ?>
    </div>
</div>
