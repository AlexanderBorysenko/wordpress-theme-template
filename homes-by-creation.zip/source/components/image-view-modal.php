<div class="image-view-modal" id="image-view-modal">
    <div class="image-view-modal__content">
        <button class="image-view-modal__close-button">
            <svg class="image-view-modal__close-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                viewBox="0 0 24 24">
                <path
                    d="M12 10.586l-4.95-4.95-1.414 1.414 4.95 4.95-4.95 4.95 1.414 1.414 4.95-4.95 4.95 4.95 1.414-1.414-4.95-4.95 4.95-4.95-1.414-1.414-4.95 4.95z" />
            </svg>
        </button>
        <div class="image-view-modal__image-wrapper">
            <img src="" class="image-view-modal__image">
        </div>
    </div>
</div>
