<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('gallery', 'Gallery')
    ->add_fields([
        // select use_global_gallery or use_custom_gallery
        Field::make('select', 'gallery_type', 'Gallery Type')
            ->add_options([
                'use_global_gallery' => 'Use Global Gallery',
                'use_custom_gallery' => 'Use Custom Gallery',
            ])
            ->set_default_value('use_custom_gallery'),

        // if use_custom_gallery -> media_gallery field
        Field::make('media_gallery', 'images', 'Gallery')
            ->set_conditional_logic([
                'relation' => 'AND',
                [
                    'field' => 'gallery_type',
                    'value' => 'use_custom_gallery',
                    'compare' => '=',
                ],
            ]),

        Field::make('text', 'items_limit', 'Items Limit')
            ->set_conditional_logic([
                'relation' => 'AND',
                [
                    'field' => 'gallery_type',
                    'value' => 'use_global_gallery',
                    'compare' => '=',
                ],
            ])->set_default_value('12'),

        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_icon('format-gallery')
    ->set_category('theme-blocks')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        ?>
    <div class="container <?= $margin_bottom ?>">
        <?php
            if (isset ($images) && !empty ($images) && $gallery_type === 'use_custom_gallery'):
                component('gallery', [
                    'items' => array_map(function ($image) {
                    return get_image($image);
                }, $images)
                ]);
            else:
                $limit = intval($items_limit);
                if ($limit > 0):
                    component('gallery', [
                        'limit' => $limit,
                    ]);
                else:
                    component('gallery');
                endif;
            endif;
            ?>
    </div>
    <?php
    });