<ul class="header-menu-column-list <?= $class ?>" id="<?= $id ?>" aria-labelledby="<?= $id ?>-toggle-button">
    <?php
    foreach ($items as $key => $item):
        ?>
        <li class="header-menu-column-list__item">
            <a class="header-menu-column-list__link" href="<?= $item['href'] ?>">
                <?= $item['title'] ?>
            </a>
        </li>
        <?php
    endforeach;
    ?>
</ul>
