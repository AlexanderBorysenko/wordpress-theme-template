<div class="post-publish-info <?= $class ?>">
    <p class="post-publish-info__author">By
        <?= $author ?>
    </p>
    |
    <p class="post-publish-info__date">
        <?= $date ?>
    </p>
</div>
