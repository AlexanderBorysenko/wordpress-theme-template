export const initContactForms = () => {
    const contactForms = document.querySelectorAll
        <HTMLFormElement>
        ('.contact-form');

    // for each contactForm -> select submit button -> add event listener -> prevent default -> fetch wp-admin/admin-ajax.php?action=main_contact_form_submit with form data as POST request -> handle response -> if response is success -> redirect to /thank-you -> if response is error -> display error message

    contactForms.forEach((contactForm) => {
        const submitButton = contactForm.querySelector('button[type="submit"]');

        submitButton.addEventListener('click', (event) => {
            event.preventDefault();

            const formData = new FormData(contactForm);

            contactForm.classList.add('_processing');

            fetch('/wp-admin/admin-ajax.php?action=main_contact_form_submit', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        window.location.href = data.data.redirect;
                    } else {
                        alert(data.data);
                    }
                }).finally(() => {
                    contactForm.classList.remove('_processing');
                });
        });
    });
}