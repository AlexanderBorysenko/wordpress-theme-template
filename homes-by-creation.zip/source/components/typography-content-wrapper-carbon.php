<?php
use Carbon_Fields\Block;

Block::make('typography-content-wrapper', 'Typography Content Wrapper')
    ->add_tab('Content', [
        get_margin_bottom_select_field(),
    ])
    ->set_inner_blocks()
    ->set_inner_blocks_position('below')
    ->set_allowed_inner_blocks([
        'core/paragraph',
        'core/heading',
        'core/list',
        'core/quote',
        'core/image',
        'core/table',
        'core/separator',
        'core/shortcode',
        'carbon-fields/gallery'
    ])
    ->set_inner_blocks_template([
        ['core/heading', ['level' => '2']],
    ])
    ->set_category('theme-blocks')
    ->set_icon('text')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('typography-content-wrapper', [
            'content' => $inner_blocks,
            'class' => 'container ' . $margin_bottom,
        ]);
    });