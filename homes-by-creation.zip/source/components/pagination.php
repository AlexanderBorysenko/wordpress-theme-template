<?php
global $query;
if (!$query) {
    global $wp_query;
    $query = $wp_query;
}
$args = array(
    'base' => str_replace(999999999, '%#%', get_pagenum_link(999999999)),
    'format' => '?paged=%#%',
    'current' => max(1, get_query_var('paged')),
    'total' => $query->max_num_pages,
    'prev_text' => 'Previous',
    'next_text' => 'Next',
);

if (isset ($paginate_links_args)) {
    $args = array_merge($args, $paginate_links_args);
}
?>

<nav class="pagination <?= $class ?>">
    <?= paginate_links($args) ?>
</nav>
