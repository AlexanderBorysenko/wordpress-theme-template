import { fadeToggleModal, addActiveModalWindowChangeListener } from '../scripts/modal';

export const initHeaderNavigation = (): void => {
    const subMenus = document.querySelectorAll<HTMLElement>('.header-navigation__submenu');
    subMenus.forEach((subMenu) => {
        const id = subMenu.id;
        if (!id) return;

        subMenu.addEventListener('click', (e: Event) => {
            if (e.target === subMenu) fadeToggleModal(id);
        });

        const togglers = document.querySelectorAll<HTMLElement>(`[aria-controls="${id}"]`);
        togglers.forEach((toggler) => {
            addActiveModalWindowChangeListener(newId => {
                toggler.classList.toggle('_active', id === newId);
            });
            toggler.addEventListener('click', (e) => {
                e.preventDefault();
                fadeToggleModal(id);
            });
        })
    })
}