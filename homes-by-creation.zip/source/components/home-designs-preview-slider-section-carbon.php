<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('home-designs-preview-slider-section', 'Home Designs Preview Slider')
    ->add_tab('Content', [
        Field::make('text', 'pre_title', 'Title')->set_default_value('APARTMENTS & COMPLEX'),
        Field::make('text', 'title', 'Title')->set_default_value('Explore & select your apartments'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_icon('admin-multisite')
    ->set_category('theme-blocks')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component(
            'home-designs-preview-slider-section',
            [
                'pre_title' => $pre_title,
                'title' => $title,
                'class' => $margin_bottom
            ]
        );
    });