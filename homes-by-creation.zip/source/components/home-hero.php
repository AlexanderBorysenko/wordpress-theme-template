<section class="home-hero container <?= $class ?>">
    <div class="home-hero__main">
        <hgroup>
            <?= component(
                'hero-title',
                [
                    'text' => $title,
                ]
            ) ?>
            <?= component(
                'regular-subtitle',
                [
                    'text' => $subtitle,
                ]
            ) ?>
        </hgroup>
        <p class="home-hero__text fw-400 ff-anek-latin">
            <?= $text ?>
        </p>
        <?= component(
            'primary-button',
            [
                'class' => '_regular-dark',
                'href' => carbon_get_theme_option('crb_contact_page_link'),
                'text' => 'Contact Us',
            ]
        ) ?>
    </div>
    <div class="home-hero__image-wrapper">
        <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
            height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" loading="eager" />
    </div>
</section>
