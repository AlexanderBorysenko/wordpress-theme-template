<section class="home-designs-preview-slider-section <?= $class ?>">
    <div class="home-designs-preview-slider-section__inner container">
        <div class="flex-row gap-2 justify-between align-end mb-3-5">
            <hgroup>
                <?php if ($pre_title): ?>
                    <?= component(
                        'decorated-pre-section-title',
                        [
                            'text' => $pre_title,
                            'class' => 'mb-1-5'
                        ]
                    ) ?>
                <?php endif; ?>
                <?php if ($title): ?>
                    <?= component(
                        'section-title',
                        [
                            'text' => $title,
                            'class' => 'lh-100'
                        ]
                    ) ?>
                <?php endif; ?>
            </hgroup>
            <?= component('primary-button', [
                'href' => get_post_type_archive_link('home-design'),
                'class' => '_light-bordered home-designs-preview-slider-section__button',
                'text' => 'Learn More'
            ]) ?>
        </div>
        <?= component('home-designs-slider') ?>
    </div>
</section>
