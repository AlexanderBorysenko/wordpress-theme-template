<div class="<?= $class ?>">
    <div class="about-quote container <?= $inner_class ?>">
        <div class="about-quote__inner-wrapper">
            <blockquote class="about-quote__inner">
                <p class="about-quote__text">
                    <?= $text ?>
                </p>
                <img class="about-quote__logo" src="<?= get_template_directory_uri() ?>/images/about-quote-logo.svg"
                    alt="Homes By Creation White Logo" width="118" height="149" loading="lazy">
            </blockquote>
        </div>
    </div>
</div>
