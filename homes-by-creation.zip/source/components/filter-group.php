<div class="filter-group">
    <h4 class="filter-group__title">
        <?= $title ?>
    </h4>
    <ul class="filter-group__items">
        <?php foreach ($filters as $filter): ?>
            <li class="filter-group__item">
                <?= component('filter-item', [
                    'group_name' => $filter['taxonomy'],
                    'name' => $filter['name'],
                    'value' => $filter['slug'],
                    'selected' => $filter['selected'],
                ]) ?>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
