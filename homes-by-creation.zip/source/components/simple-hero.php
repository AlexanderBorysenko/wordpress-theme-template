<section class="simple-hero <?= $class ?>">
    <div class="container simple-hero__inner">
        <?= component('hero-title', [
            'text' => $title,
            'class' => 'simple-hero__title'
        ]) ?>
        <?= $content ?>
    </div>
</section>
