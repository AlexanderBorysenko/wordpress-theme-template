<?php $randomKey = substr(md5(microtime()), 0, 8); ?>
<section class="communities-demonstration-section container <?= $class ?>">
    <div class="communities-demonstration-section__main-wrapper">
        <?php if ($title):
            component('section-title', ['text' => $title]);
        endif; ?>
        <?php if ($subtitle):
            component('regular-subtitle', ['text' => $subtitle]);
        endif; ?>
        <?php if ($text): ?>
            <p>
                <?= $text ?>
            </p>
        <?php endif; ?>
        <ul class="communities-demonstration-section__list">
            <?php
            foreach ($items as $key => $item):
                ?>
                <li class="communities-demonstration-section__item <?= $key === 0 ? '_active' : '' ?>"
                    data-button="image-<?= $randomKey . '-' . $key ?>">
                    <span class="communities-demonstration-section__item-logo">
                        <?php $item_index = $key + 1; ?>
                        <?= $item_index < 10 ? '0' . $item_index : $item_index ?>
                    </span>
                    <span class="communities-demonstration-section__item-title">
                        <?= $item['title'] ?>
                    </span>
                    <span class="communities-demonstration-section__item-text">
                        <?= $item['subtitle'] ?>
                    </span>
                </li>
                <?php
            endforeach;
            ?>
        </ul>
    </div>

    <div class="communities-demonstration-section__image-container">
        <?php
        foreach ($items as $key => $item):
            if (!$item['image'])
                continue;
            ?>
            <img class="communities-demonstration-section__image image-<?= $randomKey . '-' . $key ?> <?= $key === 0 ? '_active' : '' ?>"
                src="<?= $item['image']['src'] ?>" width="<?= $item['image']['width'] ?>"
                height="<?= $item['image']['height'] ?>" loading="lazy" srcset="<?= $item['image']['srcset'] ?>"
                alt="<?= $item['title'] ?>" />
            <?php
        endforeach;
        ?>
    </div>
    <div class="communities-demonstration-section__decorations container"></div>
</section>
