<ul class="quick-possession-metriks-list <?= $class ?>">
    <li class="quick-possession-metriks-list__item">
        <span class="quick-possession-metriks-list__item-title">
            Bed
        </span>
        <span class="quick-possession-metriks-list__item-value">
            <?= $bedrooms ?>
        </span>
    </li>
    <li class="quick-possession-metriks-list__item">
        <span class="quick-possession-metriks-list__item-title">
            Bath
        </span>
        <span class="quick-possession-metriks-list__item-value">
            <?= $bathrooms ?>
        </span>
    </li>
    <li class="quick-possession-metriks-list__item">
        <span class="quick-possession-metriks-list__item-title">
            SQ FT
        </span>
        <span class="quick-possession-metriks-list__item-value">
            <?= $sq_ft ?>
        </span>
    </li>
</ul>
