<?php $formId = uniqid('contact-form-'); ?>
<form action="/" method="POST" class="contact-form" id="<?= $formId ?>">
    <div class="grid gap-0-5 contact-form__fields">
        <input type="hidden" name="form_id" value="<?= $formId ?>" />
        <label class="form-field grid-col-6 grid-tw-col-12">
            <span class="form-field__label">Name</span>
            <input name="name" type="text" class="form-field__input" />
        </label>
        <label class="form-field grid-col-6 grid-tw-col-12">
            <span class="form-field__label">Subject</span>
            <input name="subject" type="text" class="form-field__input" required />
        </label>
        <label class="form-field grid-col-6 grid-tw-col-12">
            <span class="form-field__label">Phone</span>
            <input name="phone" type="tel" class="form-field__input" required />
        </label>
        <label class="form-field grid-col-6 grid-tw-col-12">
            <span class="form-field__label">Mail</span>
            <input name="email" type="email" class="form-field__input" required />
        </label>
        <label class="form-field grid-col-12">
            <textarea name="message" type="message" placeholder="Message" class="form-field__textarea"></textarea>
        </label>
    </div>
    <button type="submit" class="primary-button _regular-dark">
        <span class="primary-button__body">
            Submit
        </span>
    </button>
</form>
