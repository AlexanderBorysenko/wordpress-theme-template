<?php
ob_start();
?>
<div>
    <h2 class="ls-1 color-grey fw-600 fs-1 uppercase mb-2">BUILDING OVERVIEW</h2>
    <?= component(
        'header-menu-column-list',
        [
            'items' => carbon_get_theme_option('crb_building_overview_menu'),
            'class' => 'what-we-build-megamenu__list',
        ]
    ) ?>
</div>
<div>
    <h2 class="ls-1 color-grey fw-600 fs-1 uppercase mb-1">Communities</h2>
    <div class="grid gap-0-5">
        <?php
        $recent_communities = new WP_Query([
            'posts_per_page' => -1,
            'post_type' => 'community',
            'post_status' => 'publish',
        ]);
        while ($recent_communities->have_posts()):
            $recent_communities->the_post();
            component(
                'community-link-card',
                [
                    'title' => get_the_title(),
                    'location' => carbon_get_the_post_meta('crb_location'),
                    'image' => get_the_post_thumbnail_url(null, 'medium'),
                    'href' => get_the_permalink(),
                    'class' => 'grid-col-4 grid-tw-col-6 grid-mw-col-12'
                ]
            );
            wp_reset_postdata();
        endwhile;
        ?>
    </div>
</div>
<?php
$megamenu_inner = ob_get_clean();

component('base-megamenu', [
    'class' => 'what-we-build-megamenu',
    'id' => 'what-we-build-megamenu',
    'slot' => $megamenu_inner
]);