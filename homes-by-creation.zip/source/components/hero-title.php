<h1 class="hero-title color-black ff-montserrat fw-700 fs-3 uppercase <?= $class ?>">
    <?= $text ?>
</h1>
