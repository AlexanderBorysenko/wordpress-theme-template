<?php
ob_start();
?>
<ul class="mobile-megamenu__list">
    <li>
        <a href="#what-we-build-megamenu" id="what-we-build-megamenu-toggle-button" aria-haspopup="true"
            aria-controls="what-we-build-megamenu" class="mobile-megamenu__link toggle-megamenu">
            What We build
        </a>
    </li>
    <li>
        <a href="#quick-possession-megamenu" id="quick-possession-megamenu-toggle-button" aria-haspopup="true"
            aria-controls="quick-possession-megamenu" class="mobile-megamenu__link toggle-megamenu">
            Quick Posession
        </a>
    </li>
    <li>
        <a href="#" class="mobile-megamenu__link">
            Company
        </a>
        <?= component(
            'header-menu-column-list',
            [
                'items' => carbon_get_theme_option('crb_company_navigation_menu'),
                'class' => 'mobile-megamenu__submenu',
            ]
        ) ?>
    </li>
    <li>
        <a href="<?= carbon_get_theme_option('crb_contact_page_link') ?>" class="mobile-megamenu__link">
            Contact Us
        </a>
    </li>
</ul>
<div class="mobile-megamenu__footer">
    <address class="mobile-megamenu__address">
        <?= carbon_get_theme_option('crb_head_office_address_first_line') ?>
        <br />
        <span class="color-grey">
            <?= carbon_get_theme_option('crb_head_office_address_second_line') ?>
        </span>
    </address>
    <?= component(
        'primary-button',
        [
            'class' => '_regular-dark header__button',
            'href' => 'tel:' . carbon_get_theme_option('crb_phone'),
            'text' => carbon_get_theme_option('crb_phone'),
        ]
    ) ?>
</div>

<?php
$megamenu_inner = ob_get_clean();

component('base-megamenu', [
    'class' => 'mobile-megamenu',
    'id' => 'mobile-megamenu',
    'slot' => $megamenu_inner
]);