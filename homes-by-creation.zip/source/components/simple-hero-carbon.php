<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('simple-hero', 'Simple Hero')
    ->add_tab('Content', [
        Field::make('text', 'title', 'Title'),
        Field::make('rich_text', 'content', 'Content'),
    ])
    ->add_tab('Layouting', [
        get_padding_bottom_select_field(),
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('heading')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('simple-hero', [
            'title' => $title,
            'content' => apply_filters('the_content', $content),
            'class' => $margin_bottom . ' ' . $padding_bottom,
        ]);
    });