<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('reviews-section', 'Reviews')
    ->add_tab('Content', [
        Field::make('text', 'title', 'Title'),
        Field::make('text', 'subtitle', 'Subtitle'),
        Field::make('textarea', 'text', 'Text'),
        Field::make('complex', 'items', 'Reviews')
            ->add_fields('review', 'Review', [
                Field::make('text', 'author', 'Author'),
                Field::make('textarea', 'text', 'Text'),
                Field::make('text', 'rating', 'Rating Number'),
                Field::make('text', 'rating_text', 'Rating Text')
            ])->set_layout('tabbed-horizontal')->set_header_template('<%- author %>'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('admin-comments')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('reviews-section', [
            'title' => $title,
            'subtitle' => $subtitle,
            'text' => $text,
            'items' => $items,
            'class' => $margin_bottom
        ]);
    });