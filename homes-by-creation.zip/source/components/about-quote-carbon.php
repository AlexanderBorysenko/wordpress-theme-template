<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('about-quote', 'About Quote')
    ->add_tab('content', [
        Field::make('textarea', 'text', 'Text'),
    ])
    ->add_tab('Styling', [
        get_background_select_field('background', 'Section Background'),
        get_background_select_field('inner_background', 'Inner Background'),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('format-quote')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('about-quote', [
            'text' => $text,
            'class' => $margin_bottom . ' ' . $background,
            'inner_class' => $inner_background,
        ]);
    });