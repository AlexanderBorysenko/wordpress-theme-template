<ul class="footer-socials <?= $class ?>">
    <li class="footer-socials__item">
        <a href="<?= carbon_get_theme_option('crb_instagram_link') ?>" target="_blank" rel="noopener noreferrer"
            class="footer-socials__link">
            <svg>
                <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#instagram-icon"></use>
            </svg>
        </a>
    </li>
    <li class="footer-socials__item">
        <a href="<?= carbon_get_theme_option('crb_facebook_link') ?>" target="_blank" rel="noopener noreferrer"
            class="footer-socials__link">
            <svg>
                <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#facebook-icon"></use>
            </svg>
        </a>
    </li>
    <li class="footer-socials__item">
        <a href="
            <?= carbon_get_theme_option('crb_linkedin_link') ?>" target="_blank" rel="noopener noreferrer"
            class="footer-socials__link">
            <svg>
                <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#linkedin-icon"></use>
            </svg>
        </a>
    </li>
    <li class="footer-socials__item">
        <a href="<?= carbon_get_theme_option('crb_twitter_link') ?>" target="_blank" rel="noopener noreferrer"
            class="footer-socials__link">
            <svg>
                <use xlink:href="<?= get_template_directory_uri() ?>/source/images/icons.svg#twitter-icon"></use>
            </svg>
        </a>
    </li>
</ul>
