<section class="image-with-content-section <?= $class ?>">
    <div class="image-with-content-section__inner-layout <?= $inner_class ?> container">
        <div class="image-with-content-section__main pt-2 pb-1">
            <?php if ($pre_title): ?>
                <?= component('decorated-pre-section-title', [
                    'text' => $pre_title,
                    'class' => 'mb-3-5'
                ]) ?>
            <?php endif; ?>
            <?php if ($title): ?>
                <?= component('section-title', [
                    'text' => $title,
                    'class' => "mb-2"
                ]) ?>
            <?php endif; ?>

            <div class="image-with-content-section__content <?= $content_class ?>">
                <?= $content ?>
            </div>
        </div>
        <div class="image-with-content-section__image-container">
            <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
                height="<?= $image['height'] ?>" loading="lazy" srcset="<?= $image['srcset'] ?>" />
        </div>
    </div>
</section>
