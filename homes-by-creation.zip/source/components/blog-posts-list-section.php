<section class="blog-posts-list-section container <?= $class ?>">
    <div class="flex-row justify-between gap-2 align-end mb-3-5">
        <hgroup>
            <?=
                component('decorated-pre-section-title', [
                    'text' => $pre_title,
                    'class' => 'mb-1-5'
                ]);
            ?>
            <?=
                component('section-title', [
                    'text' => $title,
                    'class' => 'lh-100'
                ]);
            ?>
        </hgroup>
        <?= component('primary-button', [
            'href' => get_post_type_archive_link('blog'),
            'text' => 'View All',
            'class' => 'blog-posts-list-section__button _light-bordered'
        ]) ?>
    </div>
    <?=
        component(
            'blog-posts-list',
            [
                'items' => $items,
            ]
        );
    ?>
</section>
