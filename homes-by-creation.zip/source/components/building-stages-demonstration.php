<section class="building-stages-demonstration container <?= $class ?>">
    <div class="building-stages-demonstration__title-container mb-4-5">
        <hgroup>
            <?php if ($pre_title): ?>
                <?= component('decorated-pre-section-title', [
                    'text' => $pre_title,
                    'class' => 'building-stages-demonstration__pre-section-title'
                ]) ?>
            <?php endif; ?>
            <?= component('section-title', [
                'text' => $title,
                'class' => 'building-stages-demonstration__title fs-2 ff-montserrat uppercase fw-700'
            ]) ?>
        </hgroup>
        <p class="building-stages-demonstration__title-text">
            <?= $text ?>
        </p>
    </div>

    <div class="building-stages-demonstration__main">
        <div class="building-stages-demonstration__inner-main">
            <?= component('simple-gallery-slider', [
                'class' => 'building-stages-demonstration__image-container',
                'items' => $images,
            ]) ?>
        </div>
        <ul class="building-stages-demonstration__list">
            <?php foreach ($stages as $stage): ?>
                <li class="building-stages-demonstration__item <?= $stage['status'] ?>">
                    <p class="building-stages-demonstration__input-container">
                        <span>
                            <?= $stage['phase'] ?>
                        </span>
                        <span>
                            <?= $stage['title'] ?>
                        </span>
                    </p>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
