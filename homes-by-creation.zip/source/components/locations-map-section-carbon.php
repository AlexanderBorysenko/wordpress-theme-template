<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('locations-map-section', 'Locations Map')
    ->add_tab('Background Styling', [
        get_background_select_field(),
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('location-alt')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component('locations-map-section', [
            'class' => $background,
        ]);
    });