<nav class="footer-menu <?= $class ?>">
    <?php
    $footer_menu_columns = carbon_get_theme_option('crb_footer_menu');
    ?>
    <?php foreach ($footer_menu_columns as $column): ?>
        <ul class="footer-menu__list">
            <li class="footer-menu__head-item">
                <?= $column['title'] ?>
            </li>
            <?php foreach ($column['items'] as $item): ?>
                <li class="footer-menu__item">
                    <a href="<?= $item['href'] ?>" class="footer-menu__link">
                        <?= $item['title'] ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endforeach; ?>
</nav>
