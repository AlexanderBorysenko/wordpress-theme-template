<label class="filter-item">
    <input type="checkbox" name="<?= $group_name ?>[]" value="<?= $value ?>" <?= $selected ? 'checked' : '' ?> />
    <span class="filter-item__inner">
        <?= $name ?>
    </span>
</label>
