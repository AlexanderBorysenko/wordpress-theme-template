<section class="contact-us-section <?= $class ?>" id="contact-us-section">
    <div class="contact-us-section__info-part ff-montserrat fs-1-25">
        <p class="contact-us-section__info-pre-title">
            Contact Us
        </p>
        <?= component('section-title', [
            'text' => $title ?? 'Build your legacy with us.',
            'class' => 'mb-2 lh-100'
        ]) ?>
        <p class="mb-2 ff-anek-latin">
            <?= $text ?? 'Contact the Homes by Creation team about how we can help build your future.' ?>
        </p>
        <div class="mb-2 uppercase">
            <h3 class="fs-1-25 fw-700 mb-0-5">Visit us</h3>
            <address class="ls-0-02 fw-600 fs-1">
                <?= carbon_get_theme_option('crb_head_office_address_first_line') ?>
                <br />
                <span class="color-semi-grey">
                    <?= carbon_get_theme_option('crb_head_office_address_second_line') ?>
                </span>
            </address>
        </div>
        <div class="mb-2 uppercase">
            <h3 class="fs-1-25 fw-700 mb-0-5">Call us</h3>
            <a href="tel:<?= carbon_get_theme_option('crb_phone') ?>" class="ls-0-02 fw-600 fs-1">
                <?= carbon_get_theme_option('crb_phone') ?> <br />
                </span>
            </a>
        </div>
        <div class="uppercase">
            <h3 class="fs-1-25 fw-700 mb-0-5">Email</h3>
            <a href="mailto:<?= carbon_get_theme_option('crb_email') ?>" class="ls-0-02 fw-600 fs-1">
                <?= carbon_get_theme_option('crb_email') ?>
            </a>
        </div>
    </div>
    <div class="contact-us-section__form-part">
        <hgroup class="mb-2">
            <?= component('decorated-pre-section-title', [
                'text' => 'REACH OUT',
                'class' => 'mb-1'
            ]) ?>
            <?= component('section-title', [
                'text' => 'Send Us a Quick Message',
                'class' => 'lh-100'
            ]) ?>
        </hgroup>
        <?= component('contact-form') ?>
    </div>
</section>
