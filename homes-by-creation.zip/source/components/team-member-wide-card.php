<article class="team-member-wide-card color-white ff-montserrat <?= $class ?>">
    <div class="team-member-wide-card__image">
        <img src="<?= $image['src'] ?>" alt="<?= $image['alt'] ?>" width="<?= $image['width'] ?>"
            height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>" sizes="<?= $image['sizes'] ?>"
            loading="lazy" />
    </div>
    <div class="team-member-wide-card__main">
        <h3 class="team-member-wide-card__title fs-1-5 lh-100 mb-0-75 uppercase fw-700">
            <?= $name ?>
        </h3>
        <p class="team-member-wide-card__subtitle ff-anek-latin uppercase mb-0-75 fs-1-125">
            <?= $role ?>
        </p>
        <?= component(
            'primary-button',
            [
                'class' => '_regular-dark team-member-wide-card__phone mb-0-75',
                'href' => 'tel:' . $phone,
                'text' => $phone,
            ]
        ) ?>
        <a class="team-member-wide-card__email underline fw-700 color-white" href="mailto:<?= $email ?>">
            <?= $email ?>
        </a>
    </div>
</article>
