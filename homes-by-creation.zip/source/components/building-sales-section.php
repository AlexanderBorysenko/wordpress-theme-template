<section class="building-sales-section <?= $class ?>">
    <div class="container grid building-sales-section__inner-wrapper gap-1">
        <?= component(
            'simple-gallery-slider',
            [
                'items' => $images,
                'class' => 'grid-col-6 grid-row-2'
            ]
        ) ?>
        <div class="building-sales-section__map grid-col-6">
            <img src="<?= get_template_directory_uri() ?>/images/map-placeholder.jpg" alt="Map Placeholder">
        </div>
        <?=
            component(
                'team-member-wide-card',
                [
                    'name' => $sales['name'],
                    'role' => $sales['role'],
                    'phone' => $sales['phone'],
                    'email' => $sales['email'],
                    'image' => $sales['image'],
                    'class' => 'grid-col-6 building-sales-section__sales',
                ]
            )
            ?>
    </div>
</section>
