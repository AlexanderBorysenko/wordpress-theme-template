import Swiper from 'swiper';
import { Navigation, Pagination } from 'swiper/modules';


const initSimpleGallerySlider = () => {
    const carousels = document.querySelectorAll<HTMLElement>('.simple-gallery-slider');


    carousels.forEach(carousel => {
        const prevButton = carousel.querySelector<HTMLElement>('.simple-gallery-slider__swiper-button-prev');
        const nextButton = carousel.querySelector<HTMLElement>('.simple-gallery-slider__swiper-button-next');

        new Swiper(carousel, {
            loop: true,
            modules: [Navigation, Pagination],
            navigation: {
                nextEl: nextButton,
                prevEl: prevButton
            },
            pagination: {
                el: '.simple-gallery-slider__swiper-pagination',

                clickable: false,
                dynamicBullets: true
            }
        });
    });
}

export default initSimpleGallerySlider;