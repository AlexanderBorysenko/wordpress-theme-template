<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('yoast-breadcrumbs', 'Yoast Breadcrumbs')
    ->add_fields(
        array(
            // get_padding_top_select_field(),
            // get_padding_bottom_select_field(),
        )
    )
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('admin-links')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);

        component(
            'breadcrumbs',
        );
    });