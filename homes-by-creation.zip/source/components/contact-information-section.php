<?php $locations = carbon_get_theme_option('crb_office_locations'); ?>
<section class="contact-information-section <?= $class ?>">
    <div class="container contact-information-section__inner">
        <div class="contact-information-section__location-buttons">
            <?php foreach ($locations as $key => $location): ?>
                <button class="contact-information-section__location-toggle-button <?= $key === 0 ? '_active' : '' ?>"
                    data-location="location-<?= $key ?>">
                    <?= $location['title'] ?>
                </button>
            <?php endforeach; ?>
        </div>
        <div class="contact-information-section__main">
            <?php foreach ($locations as $key => $location): ?>
                <address class="contact-information-section__location <?= $key === 0 ? '_active' : '' ?>"
                    data-location="location-<?= $key ?>">
                    <strong class="contact-information-section__location-title">
                        <?= $location['title'] ?>
                    </strong>
                    <span class="contact-information-section__location-address">
                        <?= $location['address'] ?>
                    </span>
                </address>
            <?php endforeach; ?>
            <div class="contact-information-section__company-contacts">
                <h3 class="lh-100 color-grey mb-0-5 fw-600 uppercase fs-1">
                    Phone & Emails
                </h3>
                <div class="flex-row gap-1-5 mb-1">
                    <a class="color-dark-blue underline--on-hover"
                        href="tel:<?= carbon_get_theme_option('crb_phone') ?>">
                        <span class="fw-700">
                            <?= carbon_get_theme_option('crb_phone') ?>
                        </span>
                        <span class="ff-anek-latin block color-dark-grey">Phone</span>
                    </a>
                    <a class="color-dark-blue underline--on-hover"
                        href="mailto:<?= carbon_get_theme_option('crb_email') ?>">
                        <span class="fw-700 underline">
                            <?= carbon_get_theme_option('crb_email') ?>
                        </span>
                        <span class="ff-anek-latin block color-dark-grey">Email</span>
                    </a>
                </div>
                <h3 class="lh-100 color-dark-blue mb-0-5 fw-600 uppercase fs-1">
                    Hours of Operation
                </h3>
                <p class="color-dark-blue uppercase">
                    Monday - Sunday: <strong class="fw-700">9:00am - 5:00pm</strong>
                </p>
                <p class="color-dark-blue uppercase">
                    Saturday - Sunday: <strong class="fw-700">Closed</strong>
                </p>
            </div>
            <div class="contact-information-section__contact-form-wrapper">
                <?= component('contact-form') ?>
            </div>
        </div>
        <div class="contact-information-section__map">
            <div class="contact-information-section__map-wrapper">
                <img src="<?= get_template_directory_uri() ?>/images/map-placeholder.jpg" alt="Map Placeholder">
            </div>
        </div>
    </div>
</section>
