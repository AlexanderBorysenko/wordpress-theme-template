<?php
use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make('quick-possessions-list-section', 'Quick Possessions List')
    ->add_tab('Content', [
        Field::make('text', 'title', 'Title'),
        Field::make('association', 'items', 'Quick Possessions')
            ->set_types(
                array(
                    array(
                        'type' => 'post',
                        'post_type' => 'quick-possession',
                    ),
                )
            ),
    ])
    ->add_tab('Layouting', [
        get_margin_bottom_select_field()
    ])
    ->set_mode('preview')
    ->set_category('theme-blocks')
    ->set_icon('admin-multisite')
    ->set_render_callback(function ($fields, $attributes, $inner_blocks) {
        extract($fields);
        component(
            'quick-possessions-list-section',
            [
                'title' => $title,
                'items' => array_map(function ($item) {
                    return get_post($item['id']);
                }, $items),
                'class' => $margin_bottom,
            ]
        );
    });