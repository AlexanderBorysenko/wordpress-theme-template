<a href="#mobile-megamenu" id="mobile-megamenu-toggle-button" aria-haspopup="true" aria-controls="mobile-megamenu"
    class="header__mobile-megamenu-toggle-button <?= $class ?>">
    <svg width="28" height="27" viewBox="0 0 28 27" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="2.82617" y="4.23926" width="22.0453" height="2.01104" rx="1.00552" fill="#3B55A4" />
        <rect x="2.82617" y="19.5669" width="22.0453" height="2.01104" rx="1.00552" fill="#3B55A4" />
        <rect x="2.82617" y="11.9033" width="22.0453" height="2.01104" rx="1.00552" fill="#3B55A4" />
    </svg>
</a>
