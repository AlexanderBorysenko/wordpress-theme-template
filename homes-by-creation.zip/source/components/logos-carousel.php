<div class="logos-carousel <?= $class ?>">
    <ul class="swiper-wrapper logos-carousel__swiper-wrapper">
        <?php
        foreach ($items as $key => $item):
            ?>
            <li class="logos-carousel__item swiper-slide <?= $key === 0 ? '_active' : '' ?>">
                <img src="<?= $item['image']['src'] ?>" alt="<?= $item['alt'] ?>" width="<?= $item['image']['width'] ?>"
                    height="<?= $item['image']['height'] ?>" loading="lazy" srcset="<?= $item['image']['srcset'] ?>" />
            </li>
            <?php
        endforeach;
        ?>
    </ul>
</div>
