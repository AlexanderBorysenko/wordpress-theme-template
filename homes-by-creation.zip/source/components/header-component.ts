const initHeaderComponent = (): void => {
    // not needed for now

    // const header = document.querySelector<HTMLElement>('.header');
    // if (!header) return;

    // const observer = new ResizeObserver((entries) => {
    //     for (let entry of entries) {
    //         const height = entry.contentRect.height;
    //         document.documentElement.style.setProperty('--header-height', `${height}px`);
    //     }
    // });
    // observer.observe(header);
}

export default initHeaderComponent;