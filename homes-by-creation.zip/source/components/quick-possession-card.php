<article class="quick-possession-card <?= $class ?>">
    <?php if ($is_available): ?>
        <span class="quick-possession-card-status status uppercase">Available</span>
    <?php endif; ?>
    <div class="quick-possession-card__image">
        <?php if (isset($image)): ?>
            <img src="<?= $image['src'] ?>" alt="<?= $title ?>" width="<?= $image['width'] ?>"
                height="<?= $image['height'] ?>" srcset="<?= $image['srcset'] ?>">
        <?php endif; ?>
    </div>
    <h3 class="quick-possession-card__title uppercase">
        <a href="<?= $href ?? '' ?>" class="quick-possession__link">
            <?= $title ?? '' ?>
        </a>
    </h3>
    <ul class="quick-possession-card__list">
        <li class="quick-possession-card__item">
            <span class="quick-possession-card__item-subtitle uppercase">Bed</span>
            <p>
                <?= $bedrooms ?>
            </p>
        </li>
        <li class="quick-possession-card__item">
            <span class="quick-possession-card__item-subtitle uppercase">Bath</span>
            <p>
                <?= $bathrooms ?>
            </p>
        </li>
        <li class="quick-possession-card__item">
            <span class="quick-possession-card__item-subtitle uppercase">SQ FT</span>
            <p>
                <?= $sq_ft ?>
            </p>
        </li>
    </ul>
</article>
