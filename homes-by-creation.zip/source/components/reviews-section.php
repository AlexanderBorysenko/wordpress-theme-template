<section class="reviews-section <?= $class ?>">
    <div class="reviews-section__inner container">
        <div class="reviews-section__main">
            <hgroup class="mb-3">
                <?= component('section-title', [
                    'text' => $title,
                    'class' => 'reviews-section__title'
                ]) ?>
                <p class="reviews-section__subtitle">
                    <?= $subtitle ?>
                </p>
            </hgroup>
            <p class="reviews-section__text">
                <?= $text ?>
            </p>
        </div>
        <div class="reviews-section__reviews-wrapper">
            <?php
            $first_review_column_items = array_slice($items, 0, ceil(count($items) / 2));
            ?>
            <div class="reviews-section__reviews-column">
                <?php foreach ($first_review_column_items as $item): ?>
                    <?= component('review-card', [
                        'author' => $item['author'],
                        'text' => $item['text'],
                        'rating' => $item['rating'],
                        'rating_text' => $item['rating_text']
                    ]) ?>
                <?php endforeach; ?>
            </div>
            <div class="reviews-section__reviews-column">
                <?php
                $second_review_column_items = array_slice($items, ceil(count($items) / 2));
                ?>
                <?php foreach ($second_review_column_items as $item): ?>
                    <?= component('review-card', [
                        'author' => $item['author'],
                        'text' => $item['text'],
                        'rating' => $item['rating'],
                        'rating_text' => $item['rating_text']
                    ]) ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
