import { fadeIn, fadeOut } from './fadeEffect';

// Function to get the active modal window ID
const getActiveModalWindowId = (): string => {
    return (window as any).activeModalWindow || '';
};

// Function to set the active modal window ID
const setActiveModalWindowId = (id: string): void => {
    (window as any).activeModalWindow = id;
    // Trigger the listener functions
    activeModalWindowListeners.forEach((listener) => listener(id));
};

// Array to store listener functions
const activeModalWindowListeners: ((id: string) => void)[] = [];

// Function to add a listener for active modal window changes
export const addActiveModalWindowChangeListener = (listener: (id: string) => void): void => {
    activeModalWindowListeners.push(listener);
};

// Function to remove a listener for active modal window changes
export const removeActiveModalWindowListener = (listener: (id: string) => void): void => {
    const index = activeModalWindowListeners.indexOf(listener);
    if (index !== -1) {
        activeModalWindowListeners.splice(index, 1);
    }
};

// Function to toggle the fade effect of a modal window
export const fadeToggleModal = (id: string): void => {
    // Fade out the active modal window if there is one
    if (getActiveModalWindowId()) {
        const activeModalNode = document.getElementById(getActiveModalWindowId());
        if (!activeModalNode) return;
        fadeOut(activeModalNode, {
            duration: 200
        });
    }

    // If the clicked modal window is already active, deactivate it
    if (getActiveModalWindowId() === id) {
        setActiveModalWindowId('');
        return;
    }

    // Fade in the clicked modal window and set it as active
    const modalNode = document.getElementById(id);
    if (!modalNode) return;
    fadeIn(modalNode, {
        duration: 200
    });
    setActiveModalWindowId(id);
};