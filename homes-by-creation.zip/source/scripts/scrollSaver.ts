export const saveScroll = () => {
    sessionStorage.setItem('shouldScroll', window.scrollY.toString());
}