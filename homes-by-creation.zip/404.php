<?php
get_header();

?>
<div class="container flex justify-center align-center" style="min-height: 100vh">
    <h1 class="fs-3-5 fs-sdw-2-75 fs-lmw-2-25">
        404
    </h1>
</div>
<?php

get_footer();
?>
