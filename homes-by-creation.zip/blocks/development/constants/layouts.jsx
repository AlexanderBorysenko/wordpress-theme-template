export const justifyOptions = [
	{ label: 'Initial', value: '' },
	{ label: 'Center', value: 'justify-center' },
	{ label: 'Between', value: 'justify-space-between' },
	{ label: 'Around', value: 'justify-space-around' }
];
