export const buttonTypeOptions = [
	{ label: 'Accent', value: 'btn-accent' },
	{ label: 'Btn light transparent', value: 'btn-light-transparent' },
	{ label: 'Dark', value: 'btn-dark' },
	{ label: 'Light', value: 'btn-light' }
];
