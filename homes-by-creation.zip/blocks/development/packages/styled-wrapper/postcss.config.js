module.exports = {
  plugins: {
    "postcss-nested": {},
    "postcss-import": {},
    autoprefixer: {},
  },
};
