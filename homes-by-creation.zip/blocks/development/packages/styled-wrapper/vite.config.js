import { defineConfig } from "vite";
import { createViteBlock } from "vite-plugin-gutenberg-blocks";

export default defineConfig({
	plugins: [createViteBlock()],
});
